/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents_by_openai_api_key#id DataDigitaloceanGenaiAgentsByOpenaiApiKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The UUID of the OpenAI API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents_by_openai_api_key#uuid DataDigitaloceanGenaiAgentsByOpenaiApiKey#uuid}
    */
    readonly uuid: string;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrail {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrailToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrail): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrailToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrail): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrail | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrail | undefined);
    get agentUuid(): string;
    get createdAt(): string;
    get defaultResponse(): string;
    get description(): string;
    get guardrailUuid(): string;
    get isAttached(): cdktf.IResolvable;
    get isDefault(): cdktf.IResolvable;
    get name(): string;
    get priority(): number;
    get type(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrailList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrailOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgents {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgents): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgents): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctions {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctionsToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctions): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctions): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctions | undefined);
    get apiKey(): string;
    get createdAt(): string;
    get description(): string;
    get faasname(): string;
    get faasnamespace(): string;
    get guardrailUuid(): string;
    get name(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBases {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBases): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBases): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktf.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreement {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreementToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreement): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreementToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreement): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreementOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersions {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersionsToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersions): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersions): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModel {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModel): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModel): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModel | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktf.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktf.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelVersionsList;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKey | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgents {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgents): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgents): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktf.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModel {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModel): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModel): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModel | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktf.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktf.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelVersionsList;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplate {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplate): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplate): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplate | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplate | undefined);
    get createdAt(): string;
    get description(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateModelList;
    get name(): string;
    get temperature(): number;
    get topP(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateOutputReference;
}
export interface DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgents {
}
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgents): any;
export declare function dataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgents): any;
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgents | undefined);
    private _agentGuardrail;
    get agentGuardrail(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAgentGuardrailList;
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChatbotIdentifiersList;
    private _childAgents;
    get childAgents(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsChildAgentsList;
    get createdAt(): string;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsDeploymentList;
    get description(): string;
    private _functions;
    get functions(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsFunctionsList;
    get ifCase(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsModelList;
    get modelUuid(): string;
    get name(): string;
    private _openAiApiKey;
    get openAiApiKey(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOpenAiApiKeyList;
    private _parentAgents;
    get parentAgents(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsParentAgentsList;
    get projectId(): string;
    get region(): string;
    get retrievalMethod(): string;
    get routeCreatedAt(): string;
    get routeCreatedBy(): string;
    get routeName(): string;
    get routeUuid(): string;
    get tags(): string[];
    get temperature(): number;
    private _template;
    get template(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsTemplateList;
    get topP(): number;
    get updatedAt(): string;
    get url(): string;
    get userId(): string;
}
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents_by_openai_api_key digitalocean_genai_agents_by_openai_api_key}
*/
export declare class DataDigitaloceanGenaiAgentsByOpenaiApiKey extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_agents_by_openai_api_key";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiAgentsByOpenaiApiKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiAgentsByOpenaiApiKey to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiAgentsByOpenaiApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents_by_openai_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiAgentsByOpenaiApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents_by_openai_api_key digitalocean_genai_agents_by_openai_api_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiAgentsByOpenaiApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGenaiAgentsByOpenaiApiKeyConfig);
    private _agents;
    get agents(): DataDigitaloceanGenaiAgentsByOpenaiApiKeyAgentsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    get uuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
