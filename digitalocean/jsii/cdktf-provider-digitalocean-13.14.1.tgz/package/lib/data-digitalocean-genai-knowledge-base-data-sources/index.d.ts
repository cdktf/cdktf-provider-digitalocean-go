/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiKnowledgeBaseDataSourcesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_data_sources#id DataDigitaloceanGenaiKnowledgeBaseDataSources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_data_sources#knowledge_base_uuid DataDigitaloceanGenaiKnowledgeBaseDataSources#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid: string;
}
export interface DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource {
}
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource): any;
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource): any;
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSource | undefined);
    get originalFileName(): string;
    get sizeInBytes(): string;
    get storedObjectKey(): string;
}
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob {
}
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource {
}
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource): any;
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource): any;
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSource | undefined);
    get bucketName(): string;
    get itemPath(): string;
    get region(): string;
}
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource {
}
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource): any;
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource): any;
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSource | undefined);
    get baseUrl(): string;
    get crawlingOption(): string;
    get embedMedia(): cdktf.IResolvable;
}
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasources {
}
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasources): any;
export declare function dataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasources): any;
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasources | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasources | undefined);
    get createdAt(): string;
    private _fileUploadDataSource;
    get fileUploadDataSource(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesFileUploadDataSourceList;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesLastIndexingJobList;
    private _spacesDataSource;
    get spacesDataSource(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesSpacesDataSourceList;
    get updatedAt(): string;
    get uuid(): string;
    private _webCrawlerDataSource;
    get webCrawlerDataSource(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesWebCrawlerDataSourceList;
}
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_data_sources digitalocean_genai_knowledge_base_data_sources}
*/
export declare class DataDigitaloceanGenaiKnowledgeBaseDataSources extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_knowledge_base_data_sources";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiKnowledgeBaseDataSources resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiKnowledgeBaseDataSources to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiKnowledgeBaseDataSources that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_data_sources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiKnowledgeBaseDataSources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_data_sources digitalocean_genai_knowledge_base_data_sources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiKnowledgeBaseDataSourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGenaiKnowledgeBaseDataSourcesConfig);
    private _datasources;
    get datasources(): DataDigitaloceanGenaiKnowledgeBaseDataSourcesDatasourcesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string;
    set knowledgeBaseUuid(value: string);
    get knowledgeBaseUuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
