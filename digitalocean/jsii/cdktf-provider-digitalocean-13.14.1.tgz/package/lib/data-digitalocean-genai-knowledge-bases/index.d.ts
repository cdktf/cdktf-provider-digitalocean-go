/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiKnowledgeBasesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#id DataDigitaloceanGenaiKnowledgeBases#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#filter DataDigitaloceanGenaiKnowledgeBases#filter}
    */
    readonly filter?: DataDigitaloceanGenaiKnowledgeBasesFilter[] | cdktf.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#sort DataDigitaloceanGenaiKnowledgeBases#sort}
    */
    readonly sort?: DataDigitaloceanGenaiKnowledgeBasesSort[] | cdktf.IResolvable;
}
export interface DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBasesKnowledgeBases {
}
export declare function dataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesKnowledgeBases): any;
export declare function dataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesKnowledgeBases): any;
export declare class DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBasesKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBasesKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktf.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBasesFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#all DataDigitaloceanGenaiKnowledgeBases#all}
    */
    readonly all?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#key DataDigitaloceanGenaiKnowledgeBases#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#match_by DataDigitaloceanGenaiKnowledgeBases#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#values DataDigitaloceanGenaiKnowledgeBases#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGenaiKnowledgeBasesFilterToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesFilter | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiKnowledgeBasesFilterToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesFilter | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiKnowledgeBasesFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBasesFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBasesFilter | cdktf.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktf.IResolvable;
    set all(value: boolean | cdktf.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktf.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGenaiKnowledgeBasesFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiKnowledgeBasesFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBasesFilterOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBasesSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#direction DataDigitaloceanGenaiKnowledgeBases#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#key DataDigitaloceanGenaiKnowledgeBases#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGenaiKnowledgeBasesSortToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesSort | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiKnowledgeBasesSortToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBasesSort | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiKnowledgeBasesSortOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBasesSort | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBasesSort | cdktf.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiKnowledgeBasesSortList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiKnowledgeBasesSort[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBasesSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases digitalocean_genai_knowledge_bases}
*/
export declare class DataDigitaloceanGenaiKnowledgeBases extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_knowledge_bases";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiKnowledgeBases resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiKnowledgeBases to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiKnowledgeBases that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiKnowledgeBases to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_bases digitalocean_genai_knowledge_bases} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiKnowledgeBasesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGenaiKnowledgeBasesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGenaiKnowledgeBasesKnowledgeBasesList;
    private _filter;
    get filter(): DataDigitaloceanGenaiKnowledgeBasesFilterList;
    putFilter(value: DataDigitaloceanGenaiKnowledgeBasesFilter[] | cdktf.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataDigitaloceanGenaiKnowledgeBasesFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGenaiKnowledgeBasesSortList;
    putSort(value: DataDigitaloceanGenaiKnowledgeBasesSort[] | cdktf.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktf.IResolvable | DataDigitaloceanGenaiKnowledgeBasesSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
