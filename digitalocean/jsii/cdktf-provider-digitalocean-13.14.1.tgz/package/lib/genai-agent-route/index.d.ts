/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GenaiAgentRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * The UUID of the child agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route#child_agent_uuid GenaiAgentRoute#child_agent_uuid}
    */
    readonly childAgentUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route#id GenaiAgentRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * if-case condition for the route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route#if_case GenaiAgentRoute#if_case}
    */
    readonly ifCase?: string;
    /**
    * The UUID of the parent agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route#parent_agent_uuid GenaiAgentRoute#parent_agent_uuid}
    */
    readonly parentAgentUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route#rollback GenaiAgentRoute#rollback}
    */
    readonly rollback?: boolean | cdktf.IResolvable;
    /**
    * A name for the route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route#route_name GenaiAgentRoute#route_name}
    */
    readonly routeName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route digitalocean_genai_agent_route}
*/
export declare class GenaiAgentRoute extends cdktf.TerraformResource {
    static readonly tfResourceType = "digitalocean_genai_agent_route";
    /**
    * Generates CDKTF code for importing a GenaiAgentRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenaiAgentRoute to import
    * @param importFromId The id of the existing GenaiAgentRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenaiAgentRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent_route digitalocean_genai_agent_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenaiAgentRouteConfig
    */
    constructor(scope: Construct, id: string, config: GenaiAgentRouteConfig);
    private _childAgentUuid?;
    get childAgentUuid(): string;
    set childAgentUuid(value: string);
    get childAgentUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifCase?;
    get ifCase(): string;
    set ifCase(value: string);
    resetIfCase(): void;
    get ifCaseInput(): string | undefined;
    private _parentAgentUuid?;
    get parentAgentUuid(): string;
    set parentAgentUuid(value: string);
    get parentAgentUuidInput(): string | undefined;
    private _rollback?;
    get rollback(): boolean | cdktf.IResolvable;
    set rollback(value: boolean | cdktf.IResolvable);
    resetRollback(): void;
    get rollbackInput(): boolean | cdktf.IResolvable | undefined;
    private _routeName?;
    get routeName(): string;
    set routeName(value: string);
    resetRouteName(): void;
    get routeNameInput(): string | undefined;
    get uuid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
