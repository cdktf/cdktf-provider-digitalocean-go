/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiAgentVersionsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the agent to fetch versions for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#agent_id DataDigitaloceanGenaiAgentVersions#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#id DataDigitaloceanGenaiAgentVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#filter DataDigitaloceanGenaiAgentVersions#filter}
    */
    readonly filter?: DataDigitaloceanGenaiAgentVersionsFilter[] | cdktf.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#sort DataDigitaloceanGenaiAgentVersions#sort}
    */
    readonly sort?: DataDigitaloceanGenaiAgentVersionsSort[] | cdktf.IResolvable;
}
export interface DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgents {
}
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgents): any;
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgents): any;
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgents | undefined);
    get agentName(): string;
    get childAgentUuid(): string;
    get ifCase(): string;
    get isDeleted(): cdktf.IResolvable;
    get routeName(): string;
}
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctions {
}
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctionsToTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctions): any;
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctions): any;
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctions | undefined);
    get description(): string;
    get faasName(): string;
    get faasNamespace(): string;
    get isDeleted(): cdktf.IResolvable;
    get name(): string;
}
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrails {
}
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrailsToTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrails): any;
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrailsToHclTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrails): any;
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrailsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrails | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrails | undefined);
    get isDeleted(): cdktf.IResolvable;
    get name(): string;
    get priority(): number;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrailsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrailsOutputReference;
}
export interface DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBases {
}
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBases): any;
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBases): any;
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBases | undefined);
    get isDeleted(): cdktf.IResolvable;
    get name(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiAgentVersionsAgentVersions {
}
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsToTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersions): any;
export declare function dataDigitaloceanGenaiAgentVersionsAgentVersionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentVersionsAgentVersions): any;
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentVersionsAgentVersions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentVersionsAgentVersions | undefined);
    get agentUuid(): string;
    private _attachedChildAgents;
    get attachedChildAgents(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedChildAgentsList;
    private _attachedFunctions;
    get attachedFunctions(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedFunctionsList;
    private _attachedGuardrails;
    get attachedGuardrails(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedGuardrailsList;
    private _attachedKnowledgeBases;
    get attachedKnowledgeBases(): DataDigitaloceanGenaiAgentVersionsAgentVersionsAttachedKnowledgeBasesList;
    get canRollback(): cdktf.IResolvable;
    get createdAt(): string;
    get createdByEmail(): string;
    get currentlyApplied(): cdktf.IResolvable;
    get description(): string;
    get id(): string;
    get instruction(): string;
    get k(): number;
    get maxTokens(): number;
    get modelName(): string;
    get name(): string;
    get provideCitations(): cdktf.IResolvable;
    get retrievalMethod(): string;
    get tags(): string[];
    get temperature(): number;
    get topP(): number;
    get triggerAction(): string;
    get versionHash(): string;
}
export declare class DataDigitaloceanGenaiAgentVersionsAgentVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentVersionsAgentVersionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentVersionsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#all DataDigitaloceanGenaiAgentVersions#all}
    */
    readonly all?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#key DataDigitaloceanGenaiAgentVersions#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#match_by DataDigitaloceanGenaiAgentVersions#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#values DataDigitaloceanGenaiAgentVersions#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGenaiAgentVersionsFilterToTerraform(struct?: DataDigitaloceanGenaiAgentVersionsFilter | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentVersionsFilterToHclTerraform(struct?: DataDigitaloceanGenaiAgentVersionsFilter | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentVersionsFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentVersionsFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentVersionsFilter | cdktf.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktf.IResolvable;
    set all(value: boolean | cdktf.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktf.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGenaiAgentVersionsFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentVersionsFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentVersionsFilterOutputReference;
}
export interface DataDigitaloceanGenaiAgentVersionsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#direction DataDigitaloceanGenaiAgentVersions#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#key DataDigitaloceanGenaiAgentVersions#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGenaiAgentVersionsSortToTerraform(struct?: DataDigitaloceanGenaiAgentVersionsSort | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentVersionsSortToHclTerraform(struct?: DataDigitaloceanGenaiAgentVersionsSort | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentVersionsSortOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentVersionsSort | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentVersionsSort | cdktf.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentVersionsSortList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentVersionsSort[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentVersionsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions digitalocean_genai_agent_versions}
*/
export declare class DataDigitaloceanGenaiAgentVersions extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_agent_versions";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiAgentVersions resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiAgentVersions to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiAgentVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiAgentVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent_versions digitalocean_genai_agent_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiAgentVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGenaiAgentVersionsConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _agentVersions;
    get agentVersions(): DataDigitaloceanGenaiAgentVersionsAgentVersionsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataDigitaloceanGenaiAgentVersionsFilterList;
    putFilter(value: DataDigitaloceanGenaiAgentVersionsFilter[] | cdktf.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentVersionsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGenaiAgentVersionsSortList;
    putSort(value: DataDigitaloceanGenaiAgentVersionsSort[] | cdktf.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentVersionsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
