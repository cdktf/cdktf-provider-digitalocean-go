/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiOpenaiApiKeysConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#id DataDigitaloceanGenaiOpenaiApiKeys#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#filter DataDigitaloceanGenaiOpenaiApiKeys#filter}
    */
    readonly filter?: DataDigitaloceanGenaiOpenaiApiKeysFilter[] | cdktf.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#sort DataDigitaloceanGenaiOpenaiApiKeys#sort}
    */
    readonly sort?: DataDigitaloceanGenaiOpenaiApiKeysSort[] | cdktf.IResolvable;
}
export interface DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreement {
}
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreementToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreement): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreementToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreement): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreement | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreementOutputReference;
}
export interface DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersions {
}
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersionsToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersions): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersionsToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersions): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersions | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersionsOutputReference;
}
export interface DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModels {
}
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModels): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModels): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModels | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModels | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktf.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktf.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsVersionsList;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsOutputReference;
}
export interface DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeys {
}
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeys): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeys): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeys | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    private _models;
    get models(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysModelsList;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiOpenaiApiKeysFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#all DataDigitaloceanGenaiOpenaiApiKeys#all}
    */
    readonly all?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#key DataDigitaloceanGenaiOpenaiApiKeys#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#match_by DataDigitaloceanGenaiOpenaiApiKeys#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#values DataDigitaloceanGenaiOpenaiApiKeys#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGenaiOpenaiApiKeysFilterToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysFilter | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeysFilterToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysFilter | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeysFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeysFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeysFilter | cdktf.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktf.IResolvable;
    set all(value: boolean | cdktf.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktf.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeysFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiOpenaiApiKeysFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeysFilterOutputReference;
}
export interface DataDigitaloceanGenaiOpenaiApiKeysSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#direction DataDigitaloceanGenaiOpenaiApiKeys#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#key DataDigitaloceanGenaiOpenaiApiKeys#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGenaiOpenaiApiKeysSortToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysSort | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeysSortToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeysSort | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeysSortOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeysSort | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeysSort | cdktf.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeysSortList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiOpenaiApiKeysSort[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeysSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys digitalocean_genai_openai_api_keys}
*/
export declare class DataDigitaloceanGenaiOpenaiApiKeys extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_openai_api_keys";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiOpenaiApiKeys resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiOpenaiApiKeys to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiOpenaiApiKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiOpenaiApiKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_keys digitalocean_genai_openai_api_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiOpenaiApiKeysConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGenaiOpenaiApiKeysConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _openaiApiKeys;
    get openaiApiKeys(): DataDigitaloceanGenaiOpenaiApiKeysOpenaiApiKeysList;
    private _filter;
    get filter(): DataDigitaloceanGenaiOpenaiApiKeysFilterList;
    putFilter(value: DataDigitaloceanGenaiOpenaiApiKeysFilter[] | cdktf.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataDigitaloceanGenaiOpenaiApiKeysFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGenaiOpenaiApiKeysSortList;
    putSort(value: DataDigitaloceanGenaiOpenaiApiKeysSort[] | cdktf.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktf.IResolvable | DataDigitaloceanGenaiOpenaiApiKeysSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
