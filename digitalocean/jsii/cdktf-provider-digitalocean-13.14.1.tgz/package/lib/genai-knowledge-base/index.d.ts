/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GenaiKnowledgeBaseConfig extends cdktf.TerraformMetaArguments {
    /**
    * The time when the knowledge base was added to the agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#added_to_agent_at GenaiKnowledgeBase#added_to_agent_at}
    */
    readonly addedToAgentAt?: string;
    /**
    * The unique identifier of the DigitalOcean OpenSearch database this knowledge base will use
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#database_id GenaiKnowledgeBase#database_id}
    */
    readonly databaseId?: string;
    /**
    * The unique identifier of the embedding model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#embedding_model_uuid GenaiKnowledgeBase#embedding_model_uuid}
    */
    readonly embeddingModelUuid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#id GenaiKnowledgeBase#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Indicates whether the knowledge base is public or private.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#is_public GenaiKnowledgeBase#is_public}
    */
    readonly isPublic?: boolean | cdktf.IResolvable;
    /**
    * The name of the knowledge base.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#name GenaiKnowledgeBase#name}
    */
    readonly name: string;
    /**
    * The unique identifier of the project to which the knowledge base belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#project_id GenaiKnowledgeBase#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#region GenaiKnowledgeBase#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#tags GenaiKnowledgeBase#tags}
    */
    readonly tags?: string[];
    /**
    * The unique identifier of the VPC to which the knowledge base belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#vpc_uuid GenaiKnowledgeBase#vpc_uuid}
    */
    readonly vpcUuid?: string;
    /**
    * datasources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#datasources GenaiKnowledgeBase#datasources}
    */
    readonly datasources: GenaiKnowledgeBaseDatasources[] | cdktf.IResolvable;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#last_indexing_job GenaiKnowledgeBase#last_indexing_job}
    */
    readonly lastIndexingJob?: GenaiKnowledgeBaseLastIndexingJob[] | cdktf.IResolvable;
}
export interface GenaiKnowledgeBaseDatasourcesFileUploadDataSource {
    /**
    * The original name of the uploaded file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#original_file_name GenaiKnowledgeBase#original_file_name}
    */
    readonly originalFileName?: string;
    /**
    * The size of the file in bytes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#size_in_bytes GenaiKnowledgeBase#size_in_bytes}
    */
    readonly sizeInBytes?: string;
    /**
    * The stored object key for the file
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#stored_object_key GenaiKnowledgeBase#stored_object_key}
    */
    readonly storedObjectKey?: string;
}
export declare function genaiKnowledgeBaseDatasourcesFileUploadDataSourceToTerraform(struct?: GenaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktf.IResolvable): any;
export declare function genaiKnowledgeBaseDatasourcesFileUploadDataSourceToHclTerraform(struct?: GenaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktf.IResolvable): any;
export declare class GenaiKnowledgeBaseDatasourcesFileUploadDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiKnowledgeBaseDatasourcesFileUploadDataSource | cdktf.IResolvable | undefined);
    private _originalFileName?;
    get originalFileName(): string;
    set originalFileName(value: string);
    resetOriginalFileName(): void;
    get originalFileNameInput(): string | undefined;
    private _sizeInBytes?;
    get sizeInBytes(): string;
    set sizeInBytes(value: string);
    resetSizeInBytes(): void;
    get sizeInBytesInput(): string | undefined;
    private _storedObjectKey?;
    get storedObjectKey(): string;
    set storedObjectKey(value: string);
    resetStoredObjectKey(): void;
    get storedObjectKeyInput(): string | undefined;
}
export declare class GenaiKnowledgeBaseDatasourcesFileUploadDataSourceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiKnowledgeBaseDatasourcesFileUploadDataSource[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiKnowledgeBaseDatasourcesFileUploadDataSourceOutputReference;
}
export interface GenaiKnowledgeBaseDatasourcesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#completed_datasources GenaiKnowledgeBase#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#data_source_uuids GenaiKnowledgeBase#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#phase GenaiKnowledgeBase#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#tokens GenaiKnowledgeBase#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#total_datasources GenaiKnowledgeBase#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#uuid GenaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiKnowledgeBaseDatasourcesLastIndexingJobToTerraform(struct?: GenaiKnowledgeBaseDatasourcesLastIndexingJob | cdktf.IResolvable): any;
export declare function genaiKnowledgeBaseDatasourcesLastIndexingJobToHclTerraform(struct?: GenaiKnowledgeBaseDatasourcesLastIndexingJob | cdktf.IResolvable): any;
export declare class GenaiKnowledgeBaseDatasourcesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiKnowledgeBaseDatasourcesLastIndexingJob | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiKnowledgeBaseDatasourcesLastIndexingJob | cdktf.IResolvable | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiKnowledgeBaseDatasourcesLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiKnowledgeBaseDatasourcesLastIndexingJob[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiKnowledgeBaseDatasourcesLastIndexingJobOutputReference;
}
export interface GenaiKnowledgeBaseDatasourcesSpacesDataSource {
    /**
    * The name of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#bucket_name GenaiKnowledgeBase#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The path to the item in the bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#item_path GenaiKnowledgeBase#item_path}
    */
    readonly itemPath?: string;
    /**
    * The region of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#region GenaiKnowledgeBase#region}
    */
    readonly region?: string;
}
export declare function genaiKnowledgeBaseDatasourcesSpacesDataSourceToTerraform(struct?: GenaiKnowledgeBaseDatasourcesSpacesDataSource | cdktf.IResolvable): any;
export declare function genaiKnowledgeBaseDatasourcesSpacesDataSourceToHclTerraform(struct?: GenaiKnowledgeBaseDatasourcesSpacesDataSource | cdktf.IResolvable): any;
export declare class GenaiKnowledgeBaseDatasourcesSpacesDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiKnowledgeBaseDatasourcesSpacesDataSource | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiKnowledgeBaseDatasourcesSpacesDataSource | cdktf.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _itemPath?;
    get itemPath(): string;
    set itemPath(value: string);
    resetItemPath(): void;
    get itemPathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class GenaiKnowledgeBaseDatasourcesSpacesDataSourceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiKnowledgeBaseDatasourcesSpacesDataSource[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiKnowledgeBaseDatasourcesSpacesDataSourceOutputReference;
}
export interface GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource {
    /**
    * The base URL to crawl
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#base_url GenaiKnowledgeBase#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Options for specifying how URLs found on pages should be handled.
    * - UNKNOWN: Default unknown value
    * - SCOPED: Only include the base URL.
    * - PATH: Crawl the base URL and linked pages within the URL path.
    * - DOMAIN: Crawl the base URL and linked pages within the same domain.
    * - SUBDOMAINS: Crawl the base URL and linked pages for any subdomain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#crawling_option GenaiKnowledgeBase#crawling_option}
    */
    readonly crawlingOption?: string;
    /**
    * Whether to embed media content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#embed_media GenaiKnowledgeBase#embed_media}
    */
    readonly embedMedia?: boolean | cdktf.IResolvable;
}
export declare function genaiKnowledgeBaseDatasourcesWebCrawlerDataSourceToTerraform(struct?: GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktf.IResolvable): any;
export declare function genaiKnowledgeBaseDatasourcesWebCrawlerDataSourceToHclTerraform(struct?: GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktf.IResolvable): any;
export declare class GenaiKnowledgeBaseDatasourcesWebCrawlerDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource | cdktf.IResolvable | undefined);
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _crawlingOption?;
    get crawlingOption(): string;
    set crawlingOption(value: string);
    resetCrawlingOption(): void;
    get crawlingOptionInput(): string | undefined;
    private _embedMedia?;
    get embedMedia(): boolean | cdktf.IResolvable;
    set embedMedia(value: boolean | cdktf.IResolvable);
    resetEmbedMedia(): void;
    get embedMediaInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class GenaiKnowledgeBaseDatasourcesWebCrawlerDataSourceList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiKnowledgeBaseDatasourcesWebCrawlerDataSourceOutputReference;
}
export interface GenaiKnowledgeBaseDatasources {
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#uuid GenaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
    /**
    * file_upload_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#file_upload_data_source GenaiKnowledgeBase#file_upload_data_source}
    */
    readonly fileUploadDataSource?: GenaiKnowledgeBaseDatasourcesFileUploadDataSource[] | cdktf.IResolvable;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#last_indexing_job GenaiKnowledgeBase#last_indexing_job}
    */
    readonly lastIndexingJob?: GenaiKnowledgeBaseDatasourcesLastIndexingJob[] | cdktf.IResolvable;
    /**
    * spaces_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#spaces_data_source GenaiKnowledgeBase#spaces_data_source}
    */
    readonly spacesDataSource?: GenaiKnowledgeBaseDatasourcesSpacesDataSource[] | cdktf.IResolvable;
    /**
    * web_crawler_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#web_crawler_data_source GenaiKnowledgeBase#web_crawler_data_source}
    */
    readonly webCrawlerDataSource?: GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | cdktf.IResolvable;
}
export declare function genaiKnowledgeBaseDatasourcesToTerraform(struct?: GenaiKnowledgeBaseDatasources | cdktf.IResolvable): any;
export declare function genaiKnowledgeBaseDatasourcesToHclTerraform(struct?: GenaiKnowledgeBaseDatasources | cdktf.IResolvable): any;
export declare class GenaiKnowledgeBaseDatasourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiKnowledgeBaseDatasources | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiKnowledgeBaseDatasources | cdktf.IResolvable | undefined);
    get createdAt(): string;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _fileUploadDataSource;
    get fileUploadDataSource(): GenaiKnowledgeBaseDatasourcesFileUploadDataSourceList;
    putFileUploadDataSource(value: GenaiKnowledgeBaseDatasourcesFileUploadDataSource[] | cdktf.IResolvable): void;
    resetFileUploadDataSource(): void;
    get fileUploadDataSourceInput(): cdktf.IResolvable | GenaiKnowledgeBaseDatasourcesFileUploadDataSource[] | undefined;
    private _lastIndexingJob;
    get lastIndexingJob(): GenaiKnowledgeBaseDatasourcesLastIndexingJobList;
    putLastIndexingJob(value: GenaiKnowledgeBaseDatasourcesLastIndexingJob[] | cdktf.IResolvable): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): cdktf.IResolvable | GenaiKnowledgeBaseDatasourcesLastIndexingJob[] | undefined;
    private _spacesDataSource;
    get spacesDataSource(): GenaiKnowledgeBaseDatasourcesSpacesDataSourceList;
    putSpacesDataSource(value: GenaiKnowledgeBaseDatasourcesSpacesDataSource[] | cdktf.IResolvable): void;
    resetSpacesDataSource(): void;
    get spacesDataSourceInput(): cdktf.IResolvable | GenaiKnowledgeBaseDatasourcesSpacesDataSource[] | undefined;
    private _webCrawlerDataSource;
    get webCrawlerDataSource(): GenaiKnowledgeBaseDatasourcesWebCrawlerDataSourceList;
    putWebCrawlerDataSource(value: GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | cdktf.IResolvable): void;
    resetWebCrawlerDataSource(): void;
    get webCrawlerDataSourceInput(): cdktf.IResolvable | GenaiKnowledgeBaseDatasourcesWebCrawlerDataSource[] | undefined;
}
export declare class GenaiKnowledgeBaseDatasourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiKnowledgeBaseDatasources[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiKnowledgeBaseDatasourcesOutputReference;
}
export interface GenaiKnowledgeBaseLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#completed_datasources GenaiKnowledgeBase#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#data_source_uuids GenaiKnowledgeBase#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#phase GenaiKnowledgeBase#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#tokens GenaiKnowledgeBase#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#total_datasources GenaiKnowledgeBase#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#uuid GenaiKnowledgeBase#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiKnowledgeBaseLastIndexingJobToTerraform(struct?: GenaiKnowledgeBaseLastIndexingJob | cdktf.IResolvable): any;
export declare function genaiKnowledgeBaseLastIndexingJobToHclTerraform(struct?: GenaiKnowledgeBaseLastIndexingJob | cdktf.IResolvable): any;
export declare class GenaiKnowledgeBaseLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiKnowledgeBaseLastIndexingJob | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiKnowledgeBaseLastIndexingJob | cdktf.IResolvable | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiKnowledgeBaseLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiKnowledgeBaseLastIndexingJob[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiKnowledgeBaseLastIndexingJobOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base digitalocean_genai_knowledge_base}
*/
export declare class GenaiKnowledgeBase extends cdktf.TerraformResource {
    static readonly tfResourceType = "digitalocean_genai_knowledge_base";
    /**
    * Generates CDKTF code for importing a GenaiKnowledgeBase resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenaiKnowledgeBase to import
    * @param importFromId The id of the existing GenaiKnowledgeBase that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenaiKnowledgeBase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base digitalocean_genai_knowledge_base} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenaiKnowledgeBaseConfig
    */
    constructor(scope: Construct, id: string, config: GenaiKnowledgeBaseConfig);
    private _addedToAgentAt?;
    get addedToAgentAt(): string;
    set addedToAgentAt(value: string);
    resetAddedToAgentAt(): void;
    get addedToAgentAtInput(): string | undefined;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    get embeddingModelUuidInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktf.IResolvable;
    set isPublic(value: boolean | cdktf.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    resetVpcUuid(): void;
    get vpcUuidInput(): string | undefined;
    private _datasources;
    get datasources(): GenaiKnowledgeBaseDatasourcesList;
    putDatasources(value: GenaiKnowledgeBaseDatasources[] | cdktf.IResolvable): void;
    get datasourcesInput(): cdktf.IResolvable | GenaiKnowledgeBaseDatasources[] | undefined;
    private _lastIndexingJob;
    get lastIndexingJob(): GenaiKnowledgeBaseLastIndexingJobList;
    putLastIndexingJob(value: GenaiKnowledgeBaseLastIndexingJob[] | cdktf.IResolvable): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): cdktf.IResolvable | GenaiKnowledgeBaseLastIndexingJob[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
