/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GenaiAgentConfig extends cdktf.TerraformMetaArguments {
    /**
    * Optional Anthropic API key ID to use with Anthropic models
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#anthropic_key_uuid GenaiAgent#anthropic_key_uuid}
    */
    readonly anthropicKeyUuid?: string;
    /**
    * Timestamp when the Agent was created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_at GenaiAgent#created_at}
    */
    readonly createdAt?: string;
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#id GenaiAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If case condition
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#if_case GenaiAgent#if_case}
    */
    readonly ifCase?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#instruction GenaiAgent#instruction}
    */
    readonly instruction: string;
    /**
    * K value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#k GenaiAgent#k}
    */
    readonly k?: number;
    /**
    * Ids of the knowledge base(s) to attach to the agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#knowledge_base_uuid GenaiAgent#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid?: string[];
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#max_tokens GenaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Model UUID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#model_uuid GenaiAgent#model_uuid}
    */
    readonly modelUuid: string;
    /**
    * Name of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name: string;
    /**
    * Optional OpenAI API key ID to use with OpenAI models
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#open_ai_key_uuid GenaiAgent#open_ai_key_uuid}
    */
    readonly openAiKeyUuid?: string;
    /**
    * Project ID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#project_id GenaiAgent#project_id}
    */
    readonly projectId: string;
    /**
    * Indicates if the agent should provide citations in responses
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#provide_citations GenaiAgent#provide_citations}
    */
    readonly provideCitations?: boolean | cdktf.IResolvable;
    /**
    * Region where the Agent is deployed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#region GenaiAgent#region}
    */
    readonly region: string;
    /**
    * Retrieval method used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#retrieval_method GenaiAgent#retrieval_method}
    */
    readonly retrievalMethod?: string;
    /**
    * User who created the route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#route_created_by GenaiAgent#route_created_by}
    */
    readonly routeCreatedBy?: string;
    /**
    * Route name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#route_name GenaiAgent#route_name}
    */
    readonly routeName?: string;
    /**
    * Route UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#route_uuid GenaiAgent#route_uuid}
    */
    readonly routeUuid?: string;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#tags GenaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#temperature GenaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#top_p GenaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * URL for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * User ID linked with the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#user_id GenaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * agent_guardrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#agent_guardrail GenaiAgent#agent_guardrail}
    */
    readonly agentGuardrail?: GenaiAgentAgentGuardrail[] | cdktf.IResolvable;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#anthropic_api_key GenaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: GenaiAgentAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_key_infos GenaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: GenaiAgentApiKeyInfos[] | cdktf.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_keys GenaiAgent#api_keys}
    */
    readonly apiKeys?: GenaiAgentApiKeys[] | cdktf.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#chatbot GenaiAgent#chatbot}
    */
    readonly chatbot?: GenaiAgentChatbot[] | cdktf.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#chatbot_identifiers GenaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: GenaiAgentChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * child_agents block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#child_agents GenaiAgent#child_agents}
    */
    readonly childAgents?: GenaiAgentChildAgents[] | cdktf.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#deployment GenaiAgent#deployment}
    */
    readonly deployment?: GenaiAgentDeployment[] | cdktf.IResolvable;
    /**
    * functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#functions GenaiAgent#functions}
    */
    readonly functions?: GenaiAgentFunctions[] | cdktf.IResolvable;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#knowledge_bases GenaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: GenaiAgentKnowledgeBases[] | cdktf.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#model GenaiAgent#model}
    */
    readonly model?: GenaiAgentModel[] | cdktf.IResolvable;
    /**
    * open_ai_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#open_ai_api_key GenaiAgent#open_ai_api_key}
    */
    readonly openAiApiKey?: GenaiAgentOpenAiApiKey[] | cdktf.IResolvable;
    /**
    * parent_agents block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#parent_agents GenaiAgent#parent_agents}
    */
    readonly parentAgents?: GenaiAgentParentAgents[] | cdktf.IResolvable;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#template GenaiAgent#template}
    */
    readonly template?: GenaiAgentTemplate[] | cdktf.IResolvable;
}
export interface GenaiAgentAgentGuardrail {
    /**
    * Agent UUID for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#agent_uuid GenaiAgent#agent_uuid}
    */
    readonly agentUuid?: string;
    /**
    * Default response for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#default_response GenaiAgent#default_response}
    */
    readonly defaultResponse?: string;
    /**
    * Description of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#guardrail_uuid GenaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Indicates if the Guardrail is default
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#is_default GenaiAgent#is_default}
    */
    readonly isDefault?: boolean | cdktf.IResolvable;
    /**
    * Name of Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Priority of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#priority GenaiAgent#priority}
    */
    readonly priority?: number;
    /**
    * Type of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#type GenaiAgent#type}
    */
    readonly type?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentAgentGuardrailToTerraform(struct?: GenaiAgentAgentGuardrail | cdktf.IResolvable): any;
export declare function genaiAgentAgentGuardrailToHclTerraform(struct?: GenaiAgentAgentGuardrail | cdktf.IResolvable): any;
export declare class GenaiAgentAgentGuardrailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentAgentGuardrail | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentAgentGuardrail | cdktf.IResolvable | undefined);
    private _agentUuid?;
    get agentUuid(): string;
    set agentUuid(value: string);
    resetAgentUuid(): void;
    get agentUuidInput(): string | undefined;
    get createdAt(): string;
    private _defaultResponse?;
    get defaultResponse(): string;
    set defaultResponse(value: string);
    resetDefaultResponse(): void;
    get defaultResponseInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    get isAttached(): cdktf.IResolvable;
    private _isDefault?;
    get isDefault(): boolean | cdktf.IResolvable;
    set isDefault(value: boolean | cdktf.IResolvable);
    resetIsDefault(): void;
    get isDefaultInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentAgentGuardrailList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentAgentGuardrail[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentAgentGuardrailOutputReference;
}
export interface GenaiAgentAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_by GenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentAnthropicApiKeyToTerraform(struct?: GenaiAgentAnthropicApiKey | cdktf.IResolvable): any;
export declare function genaiAgentAnthropicApiKeyToHclTerraform(struct?: GenaiAgentAnthropicApiKey | cdktf.IResolvable): any;
export declare class GenaiAgentAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentAnthropicApiKey | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentAnthropicApiKey | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentAnthropicApiKeyOutputReference;
}
export interface GenaiAgentApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_by GenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#secret_key GenaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentApiKeyInfosToTerraform(struct?: GenaiAgentApiKeyInfos | cdktf.IResolvable): any;
export declare function genaiAgentApiKeyInfosToHclTerraform(struct?: GenaiAgentApiKeyInfos | cdktf.IResolvable): any;
export declare class GenaiAgentApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentApiKeyInfos | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentApiKeyInfos | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentApiKeyInfos[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentApiKeyInfosOutputReference;
}
export interface GenaiAgentApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_key GenaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function genaiAgentApiKeysToTerraform(struct?: GenaiAgentApiKeys | cdktf.IResolvable): any;
export declare function genaiAgentApiKeysToHclTerraform(struct?: GenaiAgentApiKeys | cdktf.IResolvable): any;
export declare class GenaiAgentApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentApiKeys | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentApiKeys | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class GenaiAgentApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentApiKeys[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentApiKeysOutputReference;
}
export interface GenaiAgentChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#button_background_color GenaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#logo GenaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#primary_color GenaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#secondary_color GenaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#starting_message GenaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function genaiAgentChatbotToTerraform(struct?: GenaiAgentChatbot | cdktf.IResolvable): any;
export declare function genaiAgentChatbotToHclTerraform(struct?: GenaiAgentChatbot | cdktf.IResolvable): any;
export declare class GenaiAgentChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChatbot | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChatbot | cdktf.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class GenaiAgentChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChatbot[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChatbotOutputReference;
}
export interface GenaiAgentChatbotIdentifiers {
}
export declare function genaiAgentChatbotIdentifiersToTerraform(struct?: GenaiAgentChatbotIdentifiers | cdktf.IResolvable): any;
export declare function genaiAgentChatbotIdentifiersToHclTerraform(struct?: GenaiAgentChatbotIdentifiers | cdktf.IResolvable): any;
export declare class GenaiAgentChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChatbotIdentifiers | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChatbotIdentifiers | cdktf.IResolvable | undefined);
    get chatbotId(): string;
}
export declare class GenaiAgentChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChatbotIdentifiersOutputReference;
}
export interface GenaiAgentChildAgentsAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_by GenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentChildAgentsAnthropicApiKeyToTerraform(struct?: GenaiAgentChildAgentsAnthropicApiKey | cdktf.IResolvable): any;
export declare function genaiAgentChildAgentsAnthropicApiKeyToHclTerraform(struct?: GenaiAgentChildAgentsAnthropicApiKey | cdktf.IResolvable): any;
export declare class GenaiAgentChildAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChildAgentsAnthropicApiKey | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChildAgentsAnthropicApiKey | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentChildAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChildAgentsAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChildAgentsAnthropicApiKeyOutputReference;
}
export interface GenaiAgentChildAgentsApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_by GenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#secret_key GenaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentChildAgentsApiKeyInfosToTerraform(struct?: GenaiAgentChildAgentsApiKeyInfos | cdktf.IResolvable): any;
export declare function genaiAgentChildAgentsApiKeyInfosToHclTerraform(struct?: GenaiAgentChildAgentsApiKeyInfos | cdktf.IResolvable): any;
export declare class GenaiAgentChildAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChildAgentsApiKeyInfos | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChildAgentsApiKeyInfos | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentChildAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChildAgentsApiKeyInfos[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChildAgentsApiKeyInfosOutputReference;
}
export interface GenaiAgentChildAgentsApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_key GenaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function genaiAgentChildAgentsApiKeysToTerraform(struct?: GenaiAgentChildAgentsApiKeys | cdktf.IResolvable): any;
export declare function genaiAgentChildAgentsApiKeysToHclTerraform(struct?: GenaiAgentChildAgentsApiKeys | cdktf.IResolvable): any;
export declare class GenaiAgentChildAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChildAgentsApiKeys | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChildAgentsApiKeys | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class GenaiAgentChildAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChildAgentsApiKeys[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChildAgentsApiKeysOutputReference;
}
export interface GenaiAgentChildAgentsChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#button_background_color GenaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#logo GenaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#primary_color GenaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#secondary_color GenaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#starting_message GenaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function genaiAgentChildAgentsChatbotToTerraform(struct?: GenaiAgentChildAgentsChatbot | cdktf.IResolvable): any;
export declare function genaiAgentChildAgentsChatbotToHclTerraform(struct?: GenaiAgentChildAgentsChatbot | cdktf.IResolvable): any;
export declare class GenaiAgentChildAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChildAgentsChatbot | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChildAgentsChatbot | cdktf.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class GenaiAgentChildAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChildAgentsChatbot[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChildAgentsChatbotOutputReference;
}
export interface GenaiAgentChildAgentsChatbotIdentifiers {
}
export declare function genaiAgentChildAgentsChatbotIdentifiersToTerraform(struct?: GenaiAgentChildAgentsChatbotIdentifiers | cdktf.IResolvable): any;
export declare function genaiAgentChildAgentsChatbotIdentifiersToHclTerraform(struct?: GenaiAgentChildAgentsChatbotIdentifiers | cdktf.IResolvable): any;
export declare class GenaiAgentChildAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChildAgentsChatbotIdentifiers | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChildAgentsChatbotIdentifiers | cdktf.IResolvable | undefined);
    get chatbotId(): string;
}
export declare class GenaiAgentChildAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChildAgentsChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChildAgentsChatbotIdentifiersOutputReference;
}
export interface GenaiAgentChildAgentsDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#status GenaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#visibility GenaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function genaiAgentChildAgentsDeploymentToTerraform(struct?: GenaiAgentChildAgentsDeployment | cdktf.IResolvable): any;
export declare function genaiAgentChildAgentsDeploymentToHclTerraform(struct?: GenaiAgentChildAgentsDeployment | cdktf.IResolvable): any;
export declare class GenaiAgentChildAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChildAgentsDeployment | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChildAgentsDeployment | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class GenaiAgentChildAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChildAgentsDeployment[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChildAgentsDeploymentOutputReference;
}
export interface GenaiAgentChildAgents {
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#instruction GenaiAgent#instruction}
    */
    readonly instruction: string;
    /**
    * Model UUID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#model_uuid GenaiAgent#model_uuid}
    */
    readonly modelUuid: string;
    /**
    * Name of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name: string;
    /**
    * Project ID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#project_id GenaiAgent#project_id}
    */
    readonly projectId: string;
    /**
    * Region where the Agent is deployed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#region GenaiAgent#region}
    */
    readonly region: string;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#anthropic_api_key GenaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: GenaiAgentChildAgentsAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_key_infos GenaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: GenaiAgentChildAgentsApiKeyInfos[] | cdktf.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_keys GenaiAgent#api_keys}
    */
    readonly apiKeys?: GenaiAgentChildAgentsApiKeys[] | cdktf.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#chatbot GenaiAgent#chatbot}
    */
    readonly chatbot?: GenaiAgentChildAgentsChatbot[] | cdktf.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#chatbot_identifiers GenaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: GenaiAgentChildAgentsChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#deployment GenaiAgent#deployment}
    */
    readonly deployment?: GenaiAgentChildAgentsDeployment[] | cdktf.IResolvable;
}
export declare function genaiAgentChildAgentsToTerraform(struct?: GenaiAgentChildAgents | cdktf.IResolvable): any;
export declare function genaiAgentChildAgentsToHclTerraform(struct?: GenaiAgentChildAgents | cdktf.IResolvable): any;
export declare class GenaiAgentChildAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentChildAgents | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentChildAgents | cdktf.IResolvable | undefined);
    get agentId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    get instructionInput(): string | undefined;
    private _modelUuid?;
    get modelUuid(): string;
    set modelUuid(value: string);
    get modelUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): GenaiAgentChildAgentsAnthropicApiKeyList;
    putAnthropicApiKey(value: GenaiAgentChildAgentsAnthropicApiKey[] | cdktf.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktf.IResolvable | GenaiAgentChildAgentsAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): GenaiAgentChildAgentsApiKeyInfosList;
    putApiKeyInfos(value: GenaiAgentChildAgentsApiKeyInfos[] | cdktf.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktf.IResolvable | GenaiAgentChildAgentsApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): GenaiAgentChildAgentsApiKeysList;
    putApiKeys(value: GenaiAgentChildAgentsApiKeys[] | cdktf.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktf.IResolvable | GenaiAgentChildAgentsApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): GenaiAgentChildAgentsChatbotList;
    putChatbot(value: GenaiAgentChildAgentsChatbot[] | cdktf.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktf.IResolvable | GenaiAgentChildAgentsChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): GenaiAgentChildAgentsChatbotIdentifiersList;
    putChatbotIdentifiers(value: GenaiAgentChildAgentsChatbotIdentifiers[] | cdktf.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktf.IResolvable | GenaiAgentChildAgentsChatbotIdentifiers[] | undefined;
    private _deployment;
    get deployment(): GenaiAgentChildAgentsDeploymentList;
    putDeployment(value: GenaiAgentChildAgentsDeployment[] | cdktf.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktf.IResolvable | GenaiAgentChildAgentsDeployment[] | undefined;
}
export declare class GenaiAgentChildAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentChildAgents[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentChildAgentsOutputReference;
}
export interface GenaiAgentDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#status GenaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#visibility GenaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function genaiAgentDeploymentToTerraform(struct?: GenaiAgentDeployment | cdktf.IResolvable): any;
export declare function genaiAgentDeploymentToHclTerraform(struct?: GenaiAgentDeployment | cdktf.IResolvable): any;
export declare class GenaiAgentDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentDeployment | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentDeployment | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class GenaiAgentDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentDeployment[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentDeploymentOutputReference;
}
export interface GenaiAgentFunctions {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_key GenaiAgent#api_key}
    */
    readonly apiKey?: string;
    /**
    * Description of the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#faasname GenaiAgent#faasname}
    */
    readonly faasname?: string;
    /**
    * Namespace of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#faasnamespace GenaiAgent#faasnamespace}
    */
    readonly faasnamespace?: string;
    /**
    * Guardrail UUID for the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#guardrail_uuid GenaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentFunctionsToTerraform(struct?: GenaiAgentFunctions | cdktf.IResolvable): any;
export declare function genaiAgentFunctionsToHclTerraform(struct?: GenaiAgentFunctions | cdktf.IResolvable): any;
export declare class GenaiAgentFunctionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentFunctions | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentFunctions | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _faasname?;
    get faasname(): string;
    set faasname(value: string);
    resetFaasname(): void;
    get faasnameInput(): string | undefined;
    private _faasnamespace?;
    get faasnamespace(): string;
    set faasnamespace(value: string);
    resetFaasnamespace(): void;
    get faasnamespaceInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentFunctionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentFunctions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentFunctionsOutputReference;
}
export interface GenaiAgentKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#completed_datasources GenaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#data_source_uuids GenaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#phase GenaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#tokens GenaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#total_datasources GenaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentKnowledgeBasesLastIndexingJobToTerraform(struct?: GenaiAgentKnowledgeBasesLastIndexingJobOutputReference | GenaiAgentKnowledgeBasesLastIndexingJob): any;
export declare function genaiAgentKnowledgeBasesLastIndexingJobToHclTerraform(struct?: GenaiAgentKnowledgeBasesLastIndexingJobOutputReference | GenaiAgentKnowledgeBasesLastIndexingJob): any;
export declare class GenaiAgentKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenaiAgentKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: GenaiAgentKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface GenaiAgentKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#database_id GenaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#embedding_model_uuid GenaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#is_public GenaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#project_id GenaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#region GenaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#tags GenaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#user_id GenaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#last_indexing_job GenaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: GenaiAgentKnowledgeBasesLastIndexingJob;
}
export declare function genaiAgentKnowledgeBasesToTerraform(struct?: GenaiAgentKnowledgeBases | cdktf.IResolvable): any;
export declare function genaiAgentKnowledgeBasesToHclTerraform(struct?: GenaiAgentKnowledgeBases | cdktf.IResolvable): any;
export declare class GenaiAgentKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentKnowledgeBases | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentKnowledgeBases | cdktf.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktf.IResolvable;
    set isPublic(value: boolean | cdktf.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): GenaiAgentKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: GenaiAgentKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): GenaiAgentKnowledgeBasesLastIndexingJob | undefined;
}
export declare class GenaiAgentKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentKnowledgeBases[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentKnowledgeBasesOutputReference;
}
export interface GenaiAgentModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentModelAgreementToTerraform(struct?: GenaiAgentModelAgreement | cdktf.IResolvable): any;
export declare function genaiAgentModelAgreementToHclTerraform(struct?: GenaiAgentModelAgreement | cdktf.IResolvable): any;
export declare class GenaiAgentModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentModelAgreement | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentModelAgreement | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentModelAgreement[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentModelAgreementOutputReference;
}
export interface GenaiAgentModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#major GenaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#minor GenaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#patch GenaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function genaiAgentModelVersionsToTerraform(struct?: GenaiAgentModelVersions | cdktf.IResolvable): any;
export declare function genaiAgentModelVersionsToHclTerraform(struct?: GenaiAgentModelVersions | cdktf.IResolvable): any;
export declare class GenaiAgentModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentModelVersions | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentModelVersions | cdktf.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class GenaiAgentModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentModelVersions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentModelVersionsOutputReference;
}
export interface GenaiAgentModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#inference_name GenaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#inference_version GenaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#is_foundational GenaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#parent_uuid GenaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#provider GenaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#upload_complete GenaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktf.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#usecases GenaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#agreement GenaiAgent#agreement}
    */
    readonly agreement?: GenaiAgentModelAgreement[] | cdktf.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#versions GenaiAgent#versions}
    */
    readonly versions?: GenaiAgentModelVersions[] | cdktf.IResolvable;
}
export declare function genaiAgentModelToTerraform(struct?: GenaiAgentModel | cdktf.IResolvable): any;
export declare function genaiAgentModelToHclTerraform(struct?: GenaiAgentModel | cdktf.IResolvable): any;
export declare class GenaiAgentModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentModel | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentModel | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktf.IResolvable;
    set isFoundational(value: boolean | cdktf.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktf.IResolvable;
    set uploadComplete(value: boolean | cdktf.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktf.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): GenaiAgentModelAgreementList;
    putAgreement(value: GenaiAgentModelAgreement[] | cdktf.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktf.IResolvable | GenaiAgentModelAgreement[] | undefined;
    private _versions;
    get versions(): GenaiAgentModelVersionsList;
    putVersions(value: GenaiAgentModelVersions[] | cdktf.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktf.IResolvable | GenaiAgentModelVersions[] | undefined;
}
export declare class GenaiAgentModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentModel[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentModelOutputReference;
}
export interface GenaiAgentOpenAiApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_by GenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentOpenAiApiKeyToTerraform(struct?: GenaiAgentOpenAiApiKey | cdktf.IResolvable): any;
export declare function genaiAgentOpenAiApiKeyToHclTerraform(struct?: GenaiAgentOpenAiApiKey | cdktf.IResolvable): any;
export declare class GenaiAgentOpenAiApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentOpenAiApiKey | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentOpenAiApiKey | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentOpenAiApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentOpenAiApiKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentOpenAiApiKeyOutputReference;
}
export interface GenaiAgentParentAgentsAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_by GenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentParentAgentsAnthropicApiKeyToTerraform(struct?: GenaiAgentParentAgentsAnthropicApiKey | cdktf.IResolvable): any;
export declare function genaiAgentParentAgentsAnthropicApiKeyToHclTerraform(struct?: GenaiAgentParentAgentsAnthropicApiKey | cdktf.IResolvable): any;
export declare class GenaiAgentParentAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentParentAgentsAnthropicApiKey | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentParentAgentsAnthropicApiKey | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentParentAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentParentAgentsAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentParentAgentsAnthropicApiKeyOutputReference;
}
export interface GenaiAgentParentAgentsApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#created_by GenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#secret_key GenaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentParentAgentsApiKeyInfosToTerraform(struct?: GenaiAgentParentAgentsApiKeyInfos | cdktf.IResolvable): any;
export declare function genaiAgentParentAgentsApiKeyInfosToHclTerraform(struct?: GenaiAgentParentAgentsApiKeyInfos | cdktf.IResolvable): any;
export declare class GenaiAgentParentAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentParentAgentsApiKeyInfos | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentParentAgentsApiKeyInfos | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentParentAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentParentAgentsApiKeyInfos[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentParentAgentsApiKeyInfosOutputReference;
}
export interface GenaiAgentParentAgentsApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_key GenaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function genaiAgentParentAgentsApiKeysToTerraform(struct?: GenaiAgentParentAgentsApiKeys | cdktf.IResolvable): any;
export declare function genaiAgentParentAgentsApiKeysToHclTerraform(struct?: GenaiAgentParentAgentsApiKeys | cdktf.IResolvable): any;
export declare class GenaiAgentParentAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentParentAgentsApiKeys | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentParentAgentsApiKeys | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class GenaiAgentParentAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentParentAgentsApiKeys[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentParentAgentsApiKeysOutputReference;
}
export interface GenaiAgentParentAgentsChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#button_background_color GenaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#logo GenaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#primary_color GenaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#secondary_color GenaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#starting_message GenaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function genaiAgentParentAgentsChatbotToTerraform(struct?: GenaiAgentParentAgentsChatbot | cdktf.IResolvable): any;
export declare function genaiAgentParentAgentsChatbotToHclTerraform(struct?: GenaiAgentParentAgentsChatbot | cdktf.IResolvable): any;
export declare class GenaiAgentParentAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentParentAgentsChatbot | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentParentAgentsChatbot | cdktf.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class GenaiAgentParentAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentParentAgentsChatbot[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentParentAgentsChatbotOutputReference;
}
export interface GenaiAgentParentAgentsChatbotIdentifiers {
}
export declare function genaiAgentParentAgentsChatbotIdentifiersToTerraform(struct?: GenaiAgentParentAgentsChatbotIdentifiers | cdktf.IResolvable): any;
export declare function genaiAgentParentAgentsChatbotIdentifiersToHclTerraform(struct?: GenaiAgentParentAgentsChatbotIdentifiers | cdktf.IResolvable): any;
export declare class GenaiAgentParentAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentParentAgentsChatbotIdentifiers | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentParentAgentsChatbotIdentifiers | cdktf.IResolvable | undefined);
    get chatbotId(): string;
}
export declare class GenaiAgentParentAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentParentAgentsChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentParentAgentsChatbotIdentifiersOutputReference;
}
export interface GenaiAgentParentAgentsDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#status GenaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#visibility GenaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function genaiAgentParentAgentsDeploymentToTerraform(struct?: GenaiAgentParentAgentsDeployment | cdktf.IResolvable): any;
export declare function genaiAgentParentAgentsDeploymentToHclTerraform(struct?: GenaiAgentParentAgentsDeployment | cdktf.IResolvable): any;
export declare class GenaiAgentParentAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentParentAgentsDeployment | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentParentAgentsDeployment | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class GenaiAgentParentAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentParentAgentsDeployment[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentParentAgentsDeploymentOutputReference;
}
export interface GenaiAgentParentAgents {
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#instruction GenaiAgent#instruction}
    */
    readonly instruction: string;
    /**
    * Model UUID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#model_uuid GenaiAgent#model_uuid}
    */
    readonly modelUuid: string;
    /**
    * Name of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name: string;
    /**
    * Project ID of the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#project_id GenaiAgent#project_id}
    */
    readonly projectId: string;
    /**
    * Region where the Agent is deployed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#region GenaiAgent#region}
    */
    readonly region: string;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#anthropic_api_key GenaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: GenaiAgentParentAgentsAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_key_infos GenaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: GenaiAgentParentAgentsApiKeyInfos[] | cdktf.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#api_keys GenaiAgent#api_keys}
    */
    readonly apiKeys?: GenaiAgentParentAgentsApiKeys[] | cdktf.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#chatbot GenaiAgent#chatbot}
    */
    readonly chatbot?: GenaiAgentParentAgentsChatbot[] | cdktf.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#chatbot_identifiers GenaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: GenaiAgentParentAgentsChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#deployment GenaiAgent#deployment}
    */
    readonly deployment?: GenaiAgentParentAgentsDeployment[] | cdktf.IResolvable;
}
export declare function genaiAgentParentAgentsToTerraform(struct?: GenaiAgentParentAgents | cdktf.IResolvable): any;
export declare function genaiAgentParentAgentsToHclTerraform(struct?: GenaiAgentParentAgents | cdktf.IResolvable): any;
export declare class GenaiAgentParentAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentParentAgents | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentParentAgents | cdktf.IResolvable | undefined);
    get agentId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    get instructionInput(): string | undefined;
    private _modelUuid?;
    get modelUuid(): string;
    set modelUuid(value: string);
    get modelUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): GenaiAgentParentAgentsAnthropicApiKeyList;
    putAnthropicApiKey(value: GenaiAgentParentAgentsAnthropicApiKey[] | cdktf.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktf.IResolvable | GenaiAgentParentAgentsAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): GenaiAgentParentAgentsApiKeyInfosList;
    putApiKeyInfos(value: GenaiAgentParentAgentsApiKeyInfos[] | cdktf.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktf.IResolvable | GenaiAgentParentAgentsApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): GenaiAgentParentAgentsApiKeysList;
    putApiKeys(value: GenaiAgentParentAgentsApiKeys[] | cdktf.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktf.IResolvable | GenaiAgentParentAgentsApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): GenaiAgentParentAgentsChatbotList;
    putChatbot(value: GenaiAgentParentAgentsChatbot[] | cdktf.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktf.IResolvable | GenaiAgentParentAgentsChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): GenaiAgentParentAgentsChatbotIdentifiersList;
    putChatbotIdentifiers(value: GenaiAgentParentAgentsChatbotIdentifiers[] | cdktf.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktf.IResolvable | GenaiAgentParentAgentsChatbotIdentifiers[] | undefined;
    private _deployment;
    get deployment(): GenaiAgentParentAgentsDeploymentList;
    putDeployment(value: GenaiAgentParentAgentsDeployment[] | cdktf.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktf.IResolvable | GenaiAgentParentAgentsDeployment[] | undefined;
}
export declare class GenaiAgentParentAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentParentAgents[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentParentAgentsOutputReference;
}
export interface GenaiAgentTemplateKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#completed_datasources GenaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#data_source_uuids GenaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#phase GenaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#tokens GenaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#total_datasources GenaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: GenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | GenaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare function genaiAgentTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: GenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | GenaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare class GenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: GenaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface GenaiAgentTemplateKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#database_id GenaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#embedding_model_uuid GenaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#is_public GenaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#project_id GenaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#region GenaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#tags GenaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#user_id GenaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#last_indexing_job GenaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: GenaiAgentTemplateKnowledgeBasesLastIndexingJob;
}
export declare function genaiAgentTemplateKnowledgeBasesToTerraform(struct?: GenaiAgentTemplateKnowledgeBases | cdktf.IResolvable): any;
export declare function genaiAgentTemplateKnowledgeBasesToHclTerraform(struct?: GenaiAgentTemplateKnowledgeBases | cdktf.IResolvable): any;
export declare class GenaiAgentTemplateKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentTemplateKnowledgeBases | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentTemplateKnowledgeBases | cdktf.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktf.IResolvable;
    set isPublic(value: boolean | cdktf.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): GenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: GenaiAgentTemplateKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): GenaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
}
export declare class GenaiAgentTemplateKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentTemplateKnowledgeBases[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentTemplateKnowledgeBasesOutputReference;
}
export interface GenaiAgentTemplateModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiAgentTemplateModelAgreementToTerraform(struct?: GenaiAgentTemplateModelAgreement | cdktf.IResolvable): any;
export declare function genaiAgentTemplateModelAgreementToHclTerraform(struct?: GenaiAgentTemplateModelAgreement | cdktf.IResolvable): any;
export declare class GenaiAgentTemplateModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentTemplateModelAgreement | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentTemplateModelAgreement | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiAgentTemplateModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentTemplateModelAgreement[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentTemplateModelAgreementOutputReference;
}
export interface GenaiAgentTemplateModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#major GenaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#minor GenaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#patch GenaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function genaiAgentTemplateModelVersionsToTerraform(struct?: GenaiAgentTemplateModelVersions | cdktf.IResolvable): any;
export declare function genaiAgentTemplateModelVersionsToHclTerraform(struct?: GenaiAgentTemplateModelVersions | cdktf.IResolvable): any;
export declare class GenaiAgentTemplateModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentTemplateModelVersions | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentTemplateModelVersions | cdktf.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class GenaiAgentTemplateModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentTemplateModelVersions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentTemplateModelVersionsOutputReference;
}
export interface GenaiAgentTemplateModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#inference_name GenaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#inference_version GenaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#is_foundational GenaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#parent_uuid GenaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#provider GenaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#upload_complete GenaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktf.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#url GenaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#usecases GenaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#agreement GenaiAgent#agreement}
    */
    readonly agreement?: GenaiAgentTemplateModelAgreement[] | cdktf.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#versions GenaiAgent#versions}
    */
    readonly versions?: GenaiAgentTemplateModelVersions[] | cdktf.IResolvable;
}
export declare function genaiAgentTemplateModelToTerraform(struct?: GenaiAgentTemplateModel | cdktf.IResolvable): any;
export declare function genaiAgentTemplateModelToHclTerraform(struct?: GenaiAgentTemplateModel | cdktf.IResolvable): any;
export declare class GenaiAgentTemplateModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentTemplateModel | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentTemplateModel | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktf.IResolvable;
    set isFoundational(value: boolean | cdktf.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktf.IResolvable;
    set uploadComplete(value: boolean | cdktf.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktf.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): GenaiAgentTemplateModelAgreementList;
    putAgreement(value: GenaiAgentTemplateModelAgreement[] | cdktf.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktf.IResolvable | GenaiAgentTemplateModelAgreement[] | undefined;
    private _versions;
    get versions(): GenaiAgentTemplateModelVersionsList;
    putVersions(value: GenaiAgentTemplateModelVersions[] | cdktf.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktf.IResolvable | GenaiAgentTemplateModelVersions[] | undefined;
}
export declare class GenaiAgentTemplateModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentTemplateModel[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentTemplateModelOutputReference;
}
export interface GenaiAgentTemplate {
    /**
    * Description of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#description GenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#instruction GenaiAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * K value for the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#k GenaiAgent#k}
    */
    readonly k?: number;
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#max_tokens GenaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Name of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#name GenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#temperature GenaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#top_p GenaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * uuid of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#uuid GenaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#knowledge_bases GenaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: GenaiAgentTemplateKnowledgeBases[] | cdktf.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#model GenaiAgent#model}
    */
    readonly model?: GenaiAgentTemplateModel[] | cdktf.IResolvable;
}
export declare function genaiAgentTemplateToTerraform(struct?: GenaiAgentTemplate | cdktf.IResolvable): any;
export declare function genaiAgentTemplateToHclTerraform(struct?: GenaiAgentTemplate | cdktf.IResolvable): any;
export declare class GenaiAgentTemplateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiAgentTemplate | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiAgentTemplate | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _knowledgeBases;
    get knowledgeBases(): GenaiAgentTemplateKnowledgeBasesList;
    putKnowledgeBases(value: GenaiAgentTemplateKnowledgeBases[] | cdktf.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktf.IResolvable | GenaiAgentTemplateKnowledgeBases[] | undefined;
    private _model;
    get model(): GenaiAgentTemplateModelList;
    putModel(value: GenaiAgentTemplateModel[] | cdktf.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktf.IResolvable | GenaiAgentTemplateModel[] | undefined;
}
export declare class GenaiAgentTemplateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiAgentTemplate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiAgentTemplateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent digitalocean_genai_agent}
*/
export declare class GenaiAgent extends cdktf.TerraformResource {
    static readonly tfResourceType = "digitalocean_genai_agent";
    /**
    * Generates CDKTF code for importing a GenaiAgent resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenaiAgent to import
    * @param importFromId The id of the existing GenaiAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenaiAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_agent digitalocean_genai_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenaiAgentConfig
    */
    constructor(scope: Construct, id: string, config: GenaiAgentConfig);
    private _anthropicKeyUuid?;
    get anthropicKeyUuid(): string;
    set anthropicKeyUuid(value: string);
    resetAnthropicKeyUuid(): void;
    get anthropicKeyUuidInput(): string | undefined;
    private _createdAt?;
    get createdAt(): string;
    set createdAt(value: string);
    resetCreatedAt(): void;
    get createdAtInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifCase?;
    get ifCase(): string;
    set ifCase(value: string);
    resetIfCase(): void;
    get ifCaseInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    get instructionInput(): string | undefined;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string[];
    set knowledgeBaseUuid(value: string[]);
    resetKnowledgeBaseUuid(): void;
    get knowledgeBaseUuidInput(): string[] | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelUuid?;
    get modelUuid(): string;
    set modelUuid(value: string);
    get modelUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _openAiKeyUuid?;
    get openAiKeyUuid(): string;
    set openAiKeyUuid(value: string);
    resetOpenAiKeyUuid(): void;
    get openAiKeyUuidInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _provideCitations?;
    get provideCitations(): boolean | cdktf.IResolvable;
    set provideCitations(value: boolean | cdktf.IResolvable);
    resetProvideCitations(): void;
    get provideCitationsInput(): boolean | cdktf.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _retrievalMethod?;
    get retrievalMethod(): string;
    set retrievalMethod(value: string);
    resetRetrievalMethod(): void;
    get retrievalMethodInput(): string | undefined;
    get routeCreatedAt(): string;
    private _routeCreatedBy?;
    get routeCreatedBy(): string;
    set routeCreatedBy(value: string);
    resetRouteCreatedBy(): void;
    get routeCreatedByInput(): string | undefined;
    private _routeName?;
    get routeName(): string;
    set routeName(value: string);
    resetRouteName(): void;
    get routeNameInput(): string | undefined;
    private _routeUuid?;
    get routeUuid(): string;
    set routeUuid(value: string);
    resetRouteUuid(): void;
    get routeUuidInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _agentGuardrail;
    get agentGuardrail(): GenaiAgentAgentGuardrailList;
    putAgentGuardrail(value: GenaiAgentAgentGuardrail[] | cdktf.IResolvable): void;
    resetAgentGuardrail(): void;
    get agentGuardrailInput(): cdktf.IResolvable | GenaiAgentAgentGuardrail[] | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): GenaiAgentAnthropicApiKeyList;
    putAnthropicApiKey(value: GenaiAgentAnthropicApiKey[] | cdktf.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktf.IResolvable | GenaiAgentAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): GenaiAgentApiKeyInfosList;
    putApiKeyInfos(value: GenaiAgentApiKeyInfos[] | cdktf.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktf.IResolvable | GenaiAgentApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): GenaiAgentApiKeysList;
    putApiKeys(value: GenaiAgentApiKeys[] | cdktf.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktf.IResolvable | GenaiAgentApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): GenaiAgentChatbotList;
    putChatbot(value: GenaiAgentChatbot[] | cdktf.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktf.IResolvable | GenaiAgentChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): GenaiAgentChatbotIdentifiersList;
    putChatbotIdentifiers(value: GenaiAgentChatbotIdentifiers[] | cdktf.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktf.IResolvable | GenaiAgentChatbotIdentifiers[] | undefined;
    private _childAgents;
    get childAgents(): GenaiAgentChildAgentsList;
    putChildAgents(value: GenaiAgentChildAgents[] | cdktf.IResolvable): void;
    resetChildAgents(): void;
    get childAgentsInput(): cdktf.IResolvable | GenaiAgentChildAgents[] | undefined;
    private _deployment;
    get deployment(): GenaiAgentDeploymentList;
    putDeployment(value: GenaiAgentDeployment[] | cdktf.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktf.IResolvable | GenaiAgentDeployment[] | undefined;
    private _functions;
    get functions(): GenaiAgentFunctionsList;
    putFunctions(value: GenaiAgentFunctions[] | cdktf.IResolvable): void;
    resetFunctions(): void;
    get functionsInput(): cdktf.IResolvable | GenaiAgentFunctions[] | undefined;
    private _knowledgeBases;
    get knowledgeBases(): GenaiAgentKnowledgeBasesList;
    putKnowledgeBases(value: GenaiAgentKnowledgeBases[] | cdktf.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktf.IResolvable | GenaiAgentKnowledgeBases[] | undefined;
    private _model;
    get model(): GenaiAgentModelList;
    putModel(value: GenaiAgentModel[] | cdktf.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktf.IResolvable | GenaiAgentModel[] | undefined;
    private _openAiApiKey;
    get openAiApiKey(): GenaiAgentOpenAiApiKeyList;
    putOpenAiApiKey(value: GenaiAgentOpenAiApiKey[] | cdktf.IResolvable): void;
    resetOpenAiApiKey(): void;
    get openAiApiKeyInput(): cdktf.IResolvable | GenaiAgentOpenAiApiKey[] | undefined;
    private _parentAgents;
    get parentAgents(): GenaiAgentParentAgentsList;
    putParentAgents(value: GenaiAgentParentAgents[] | cdktf.IResolvable): void;
    resetParentAgents(): void;
    get parentAgentsInput(): cdktf.IResolvable | GenaiAgentParentAgents[] | undefined;
    private _template;
    get template(): GenaiAgentTemplateList;
    putTemplate(value: GenaiAgentTemplate[] | cdktf.IResolvable): void;
    resetTemplate(): void;
    get templateInput(): cdktf.IResolvable | GenaiAgentTemplate[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
