/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiOpenaiApiKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_key#id DataDigitaloceanGenaiOpenaiApiKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * OpenAI API Key Uuid
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_key#uuid DataDigitaloceanGenaiOpenaiApiKey#uuid}
    */
    readonly uuid: string;
}
export interface DataDigitaloceanGenaiOpenaiApiKeyModelsAgreement {
}
export declare function dataDigitaloceanGenaiOpenaiApiKeyModelsAgreementToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeyModelsAgreement): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeyModelsAgreementToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeyModelsAgreement): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeyModelsAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeyModelsAgreement | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeyModelsAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeyModelsAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeyModelsAgreementOutputReference;
}
export interface DataDigitaloceanGenaiOpenaiApiKeyModelsVersions {
}
export declare function dataDigitaloceanGenaiOpenaiApiKeyModelsVersionsToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeyModelsVersions): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeyModelsVersionsToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeyModelsVersions): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeyModelsVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeyModelsVersions | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeyModelsVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeyModelsVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeyModelsVersionsOutputReference;
}
export interface DataDigitaloceanGenaiOpenaiApiKeyModels {
}
export declare function dataDigitaloceanGenaiOpenaiApiKeyModelsToTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeyModels): any;
export declare function dataDigitaloceanGenaiOpenaiApiKeyModelsToHclTerraform(struct?: DataDigitaloceanGenaiOpenaiApiKeyModels): any;
export declare class DataDigitaloceanGenaiOpenaiApiKeyModelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiOpenaiApiKeyModels | undefined;
    set internalValue(value: DataDigitaloceanGenaiOpenaiApiKeyModels | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGenaiOpenaiApiKeyModelsAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktf.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktf.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGenaiOpenaiApiKeyModelsVersionsList;
}
export declare class DataDigitaloceanGenaiOpenaiApiKeyModelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiOpenaiApiKeyModelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_key digitalocean_genai_openai_api_key}
*/
export declare class DataDigitaloceanGenaiOpenaiApiKey extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_openai_api_key";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiOpenaiApiKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiOpenaiApiKey to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiOpenaiApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiOpenaiApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_openai_api_key digitalocean_genai_openai_api_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiOpenaiApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGenaiOpenaiApiKeyConfig);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _models;
    get models(): DataDigitaloceanGenaiOpenaiApiKeyModelsList;
    get name(): string;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    get uuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
