/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpcNatGatewayConfig extends cdktf.TerraformMetaArguments {
    /**
    * ICMP connection timeout (in seconds)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#icmp_timeout_seconds VpcNatGateway#icmp_timeout_seconds}
    */
    readonly icmpTimeoutSeconds?: number;
    /**
    * Name of the VPC NAT Gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#name VpcNatGateway#name}
    */
    readonly name: string;
    /**
    * ID of the project to which the VPC NAT Gateway will be assigned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#project_id VpcNatGateway#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the VPC NAT Gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#region VpcNatGateway#region}
    */
    readonly region: string;
    /**
    * Size of the VPC NAT Gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#size VpcNatGateway#size}
    */
    readonly size: number;
    /**
    * TCP connection timeout (in seconds)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#tcp_timeout_seconds VpcNatGateway#tcp_timeout_seconds}
    */
    readonly tcpTimeoutSeconds?: number;
    /**
    * Type of the VPC NAT Gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#type VpcNatGateway#type}
    */
    readonly type: string;
    /**
    * UDP connection timeout (in seconds)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#udp_timeout_seconds VpcNatGateway#udp_timeout_seconds}
    */
    readonly udpTimeoutSeconds?: number;
    /**
    * vpcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#vpcs VpcNatGateway#vpcs}
    */
    readonly vpcs: VpcNatGatewayVpcs[] | cdktf.IResolvable;
}
export interface VpcNatGatewayEgressesPublicGateways {
}
export declare function vpcNatGatewayEgressesPublicGatewaysToTerraform(struct?: VpcNatGatewayEgressesPublicGateways): any;
export declare function vpcNatGatewayEgressesPublicGatewaysToHclTerraform(struct?: VpcNatGatewayEgressesPublicGateways): any;
export declare class VpcNatGatewayEgressesPublicGatewaysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpcNatGatewayEgressesPublicGateways | undefined;
    set internalValue(value: VpcNatGatewayEgressesPublicGateways | undefined);
    get ipv4(): string;
}
export declare class VpcNatGatewayEgressesPublicGatewaysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpcNatGatewayEgressesPublicGatewaysOutputReference;
}
export interface VpcNatGatewayEgresses {
}
export declare function vpcNatGatewayEgressesToTerraform(struct?: VpcNatGatewayEgresses): any;
export declare function vpcNatGatewayEgressesToHclTerraform(struct?: VpcNatGatewayEgresses): any;
export declare class VpcNatGatewayEgressesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpcNatGatewayEgresses | undefined;
    set internalValue(value: VpcNatGatewayEgresses | undefined);
    private _publicGateways;
    get publicGateways(): VpcNatGatewayEgressesPublicGatewaysList;
}
export declare class VpcNatGatewayEgressesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpcNatGatewayEgressesOutputReference;
}
export interface VpcNatGatewayVpcs {
    /**
    * Indicates if this is the default VPC NAT Gateway in the VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#default_gateway VpcNatGateway#default_gateway}
    */
    readonly defaultGateway?: boolean | cdktf.IResolvable;
    /**
    * ID of the ingress VPC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#vpc_uuid VpcNatGateway#vpc_uuid}
    */
    readonly vpcUuid: string;
}
export declare function vpcNatGatewayVpcsToTerraform(struct?: VpcNatGatewayVpcs | cdktf.IResolvable): any;
export declare function vpcNatGatewayVpcsToHclTerraform(struct?: VpcNatGatewayVpcs | cdktf.IResolvable): any;
export declare class VpcNatGatewayVpcsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpcNatGatewayVpcs | cdktf.IResolvable | undefined;
    set internalValue(value: VpcNatGatewayVpcs | cdktf.IResolvable | undefined);
    private _defaultGateway?;
    get defaultGateway(): boolean | cdktf.IResolvable;
    set defaultGateway(value: boolean | cdktf.IResolvable);
    resetDefaultGateway(): void;
    get defaultGatewayInput(): boolean | cdktf.IResolvable | undefined;
    get gatewayIp(): string;
    private _vpcUuid?;
    get vpcUuid(): string;
    set vpcUuid(value: string);
    get vpcUuidInput(): string | undefined;
}
export declare class VpcNatGatewayVpcsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VpcNatGatewayVpcs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpcNatGatewayVpcsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway digitalocean_vpc_nat_gateway}
*/
export declare class VpcNatGateway extends cdktf.TerraformResource {
    static readonly tfResourceType = "digitalocean_vpc_nat_gateway";
    /**
    * Generates CDKTF code for importing a VpcNatGateway resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpcNatGateway to import
    * @param importFromId The id of the existing VpcNatGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpcNatGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/vpc_nat_gateway digitalocean_vpc_nat_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpcNatGatewayConfig
    */
    constructor(scope: Construct, id: string, config: VpcNatGatewayConfig);
    get createdAt(): string;
    private _egresses;
    get egresses(): VpcNatGatewayEgressesList;
    private _icmpTimeoutSeconds?;
    get icmpTimeoutSeconds(): number;
    set icmpTimeoutSeconds(value: number);
    resetIcmpTimeoutSeconds(): void;
    get icmpTimeoutSecondsInput(): number | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    get state(): string;
    private _tcpTimeoutSeconds?;
    get tcpTimeoutSeconds(): number;
    set tcpTimeoutSeconds(value: number);
    resetTcpTimeoutSeconds(): void;
    get tcpTimeoutSecondsInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _udpTimeoutSeconds?;
    get udpTimeoutSeconds(): number;
    set udpTimeoutSeconds(value: number);
    resetUdpTimeoutSeconds(): void;
    get udpTimeoutSecondsInput(): number | undefined;
    get updatedAt(): string;
    private _vpcs;
    get vpcs(): VpcNatGatewayVpcsList;
    putVpcs(value: VpcNatGatewayVpcs[] | cdktf.IResolvable): void;
    get vpcsInput(): cdktf.IResolvable | VpcNatGatewayVpcs[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
