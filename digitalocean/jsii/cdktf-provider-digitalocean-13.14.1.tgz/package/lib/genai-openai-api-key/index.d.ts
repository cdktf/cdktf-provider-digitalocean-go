/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GenaiOpenaiApiKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The OpenAI API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#api_key GenaiOpenaiApiKey#api_key}
    */
    readonly apiKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#id GenaiOpenaiApiKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A name for the API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#name GenaiOpenaiApiKey#name}
    */
    readonly name: string;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#model GenaiOpenaiApiKey#model}
    */
    readonly model?: GenaiOpenaiApiKeyModel[] | cdktf.IResolvable;
}
export interface GenaiOpenaiApiKeyModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#description GenaiOpenaiApiKey#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#name GenaiOpenaiApiKey#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#url GenaiOpenaiApiKey#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#uuid GenaiOpenaiApiKey#uuid}
    */
    readonly uuid?: string;
}
export declare function genaiOpenaiApiKeyModelAgreementToTerraform(struct?: GenaiOpenaiApiKeyModelAgreement | cdktf.IResolvable): any;
export declare function genaiOpenaiApiKeyModelAgreementToHclTerraform(struct?: GenaiOpenaiApiKeyModelAgreement | cdktf.IResolvable): any;
export declare class GenaiOpenaiApiKeyModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiOpenaiApiKeyModelAgreement | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiOpenaiApiKeyModelAgreement | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class GenaiOpenaiApiKeyModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiOpenaiApiKeyModelAgreement[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiOpenaiApiKeyModelAgreementOutputReference;
}
export interface GenaiOpenaiApiKeyModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#major GenaiOpenaiApiKey#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#minor GenaiOpenaiApiKey#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#patch GenaiOpenaiApiKey#patch}
    */
    readonly patch?: number;
}
export declare function genaiOpenaiApiKeyModelVersionsToTerraform(struct?: GenaiOpenaiApiKeyModelVersions | cdktf.IResolvable): any;
export declare function genaiOpenaiApiKeyModelVersionsToHclTerraform(struct?: GenaiOpenaiApiKeyModelVersions | cdktf.IResolvable): any;
export declare class GenaiOpenaiApiKeyModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiOpenaiApiKeyModelVersions | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiOpenaiApiKeyModelVersions | cdktf.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class GenaiOpenaiApiKeyModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiOpenaiApiKeyModelVersions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiOpenaiApiKeyModelVersionsOutputReference;
}
export interface GenaiOpenaiApiKeyModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#inference_name GenaiOpenaiApiKey#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#inference_version GenaiOpenaiApiKey#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#is_foundational GenaiOpenaiApiKey#is_foundational}
    */
    readonly isFoundational?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#name GenaiOpenaiApiKey#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#parent_uuid GenaiOpenaiApiKey#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#provider GenaiOpenaiApiKey#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#upload_complete GenaiOpenaiApiKey#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktf.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#url GenaiOpenaiApiKey#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#usecases GenaiOpenaiApiKey#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#agreement GenaiOpenaiApiKey#agreement}
    */
    readonly agreement?: GenaiOpenaiApiKeyModelAgreement[] | cdktf.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#versions GenaiOpenaiApiKey#versions}
    */
    readonly versions?: GenaiOpenaiApiKeyModelVersions[] | cdktf.IResolvable;
}
export declare function genaiOpenaiApiKeyModelToTerraform(struct?: GenaiOpenaiApiKeyModel | cdktf.IResolvable): any;
export declare function genaiOpenaiApiKeyModelToHclTerraform(struct?: GenaiOpenaiApiKeyModel | cdktf.IResolvable): any;
export declare class GenaiOpenaiApiKeyModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenaiOpenaiApiKeyModel | cdktf.IResolvable | undefined;
    set internalValue(value: GenaiOpenaiApiKeyModel | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktf.IResolvable;
    set isFoundational(value: boolean | cdktf.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktf.IResolvable;
    set uploadComplete(value: boolean | cdktf.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktf.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): GenaiOpenaiApiKeyModelAgreementList;
    putAgreement(value: GenaiOpenaiApiKeyModelAgreement[] | cdktf.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktf.IResolvable | GenaiOpenaiApiKeyModelAgreement[] | undefined;
    private _versions;
    get versions(): GenaiOpenaiApiKeyModelVersionsList;
    putVersions(value: GenaiOpenaiApiKeyModelVersions[] | cdktf.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktf.IResolvable | GenaiOpenaiApiKeyModelVersions[] | undefined;
}
export declare class GenaiOpenaiApiKeyModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GenaiOpenaiApiKeyModel[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenaiOpenaiApiKeyModelOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key digitalocean_genai_openai_api_key}
*/
export declare class GenaiOpenaiApiKey extends cdktf.TerraformResource {
    static readonly tfResourceType = "digitalocean_genai_openai_api_key";
    /**
    * Generates CDKTF code for importing a GenaiOpenaiApiKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenaiOpenaiApiKey to import
    * @param importFromId The id of the existing GenaiOpenaiApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenaiOpenaiApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_openai_api_key digitalocean_genai_openai_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenaiOpenaiApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: GenaiOpenaiApiKeyConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get updatedAt(): string;
    get uuid(): string;
    private _model;
    get model(): GenaiOpenaiApiKeyModelList;
    putModel(value: GenaiOpenaiApiKeyModel[] | cdktf.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktf.IResolvable | GenaiOpenaiApiKeyModel[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
