/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiModelsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#id DataDigitaloceanGenaiModels#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#filter DataDigitaloceanGenaiModels#filter}
    */
    readonly filter?: DataDigitaloceanGenaiModelsFilter[] | cdktf.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#sort DataDigitaloceanGenaiModels#sort}
    */
    readonly sort?: DataDigitaloceanGenaiModelsSort[] | cdktf.IResolvable;
}
export interface DataDigitaloceanGenaiModelsModelsAgreement {
}
export declare function dataDigitaloceanGenaiModelsModelsAgreementToTerraform(struct?: DataDigitaloceanGenaiModelsModelsAgreement): any;
export declare function dataDigitaloceanGenaiModelsModelsAgreementToHclTerraform(struct?: DataDigitaloceanGenaiModelsModelsAgreement): any;
export declare class DataDigitaloceanGenaiModelsModelsAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiModelsModelsAgreement | undefined;
    set internalValue(value: DataDigitaloceanGenaiModelsModelsAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiModelsModelsAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiModelsModelsAgreementOutputReference;
}
export interface DataDigitaloceanGenaiModelsModelsVersion {
}
export declare function dataDigitaloceanGenaiModelsModelsVersionToTerraform(struct?: DataDigitaloceanGenaiModelsModelsVersion): any;
export declare function dataDigitaloceanGenaiModelsModelsVersionToHclTerraform(struct?: DataDigitaloceanGenaiModelsModelsVersion): any;
export declare class DataDigitaloceanGenaiModelsModelsVersionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiModelsModelsVersion | undefined;
    set internalValue(value: DataDigitaloceanGenaiModelsModelsVersion | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGenaiModelsModelsVersionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiModelsModelsVersionOutputReference;
}
export interface DataDigitaloceanGenaiModelsModels {
}
export declare function dataDigitaloceanGenaiModelsModelsToTerraform(struct?: DataDigitaloceanGenaiModelsModels): any;
export declare function dataDigitaloceanGenaiModelsModelsToHclTerraform(struct?: DataDigitaloceanGenaiModelsModels): any;
export declare class DataDigitaloceanGenaiModelsModelsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiModelsModels | undefined;
    set internalValue(value: DataDigitaloceanGenaiModelsModels | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGenaiModelsModelsAgreementList;
    get createdAt(): string;
    get id(): string;
    get isFoundational(): cdktf.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktf.IResolvable;
    get url(): string;
    get uuid(): string;
    private _version;
    get version(): DataDigitaloceanGenaiModelsModelsVersionList;
}
export declare class DataDigitaloceanGenaiModelsModelsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiModelsModelsOutputReference;
}
export interface DataDigitaloceanGenaiModelsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#all DataDigitaloceanGenaiModels#all}
    */
    readonly all?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#key DataDigitaloceanGenaiModels#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#match_by DataDigitaloceanGenaiModels#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#values DataDigitaloceanGenaiModels#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGenaiModelsFilterToTerraform(struct?: DataDigitaloceanGenaiModelsFilter | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiModelsFilterToHclTerraform(struct?: DataDigitaloceanGenaiModelsFilter | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiModelsFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiModelsFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiModelsFilter | cdktf.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktf.IResolvable;
    set all(value: boolean | cdktf.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktf.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGenaiModelsFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiModelsFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiModelsFilterOutputReference;
}
export interface DataDigitaloceanGenaiModelsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#direction DataDigitaloceanGenaiModels#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#key DataDigitaloceanGenaiModels#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGenaiModelsSortToTerraform(struct?: DataDigitaloceanGenaiModelsSort | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiModelsSortToHclTerraform(struct?: DataDigitaloceanGenaiModelsSort | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiModelsSortOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiModelsSort | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiModelsSort | cdktf.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiModelsSortList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiModelsSort[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiModelsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models digitalocean_genai_models}
*/
export declare class DataDigitaloceanGenaiModels extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_models";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiModels resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiModels to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiModels that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiModels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_models digitalocean_genai_models} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiModelsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGenaiModelsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _models;
    get models(): DataDigitaloceanGenaiModelsModelsList;
    private _filter;
    get filter(): DataDigitaloceanGenaiModelsFilterList;
    putFilter(value: DataDigitaloceanGenaiModelsFilter[] | cdktf.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataDigitaloceanGenaiModelsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGenaiModelsSortList;
    putSort(value: DataDigitaloceanGenaiModelsSort[] | cdktf.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktf.IResolvable | DataDigitaloceanGenaiModelsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
