/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiAgentsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#id DataDigitaloceanGenaiAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#only_deployed DataDigitaloceanGenaiAgents#only_deployed}
    */
    readonly onlyDeployed?: boolean | cdktf.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#filter DataDigitaloceanGenaiAgents#filter}
    */
    readonly filter?: DataDigitaloceanGenaiAgentsFilter[] | cdktf.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#sort DataDigitaloceanGenaiAgents#sort}
    */
    readonly sort?: DataDigitaloceanGenaiAgentsSort[] | cdktf.IResolvable;
}
export interface DataDigitaloceanGenaiAgentsAgentsAgentGuardrail {
}
export declare function dataDigitaloceanGenaiAgentsAgentsAgentGuardrailToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsAgentGuardrail): any;
export declare function dataDigitaloceanGenaiAgentsAgentsAgentGuardrailToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsAgentGuardrail): any;
export declare class DataDigitaloceanGenaiAgentsAgentsAgentGuardrailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsAgentGuardrail | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsAgentGuardrail | undefined);
    get agentUuid(): string;
    get createdAt(): string;
    get defaultResponse(): string;
    get description(): string;
    get guardrailUuid(): string;
    get isAttached(): cdktf.IResolvable;
    get isDefault(): cdktf.IResolvable;
    get name(): string;
    get priority(): number;
    get type(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsAgentGuardrailList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsAgentGuardrailOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentsAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentsAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentsAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentsAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentsAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentsAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentsAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentsAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentsAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChildAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChildAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChildAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChildAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsChildAgents {
}
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgents): any;
export declare function dataDigitaloceanGenaiAgentsAgentsChildAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsChildAgents): any;
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsChildAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentsAgentsChildAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentsAgentsChildAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentsAgentsChildAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentsAgentsChildAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsChildAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsChildAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentsAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentsAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentsAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsFunctions {
}
export declare function dataDigitaloceanGenaiAgentsAgentsFunctionsToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsFunctions): any;
export declare function dataDigitaloceanGenaiAgentsAgentsFunctionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsFunctions): any;
export declare class DataDigitaloceanGenaiAgentsAgentsFunctionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsFunctions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsFunctions | undefined);
    get apiKey(): string;
    get createdAt(): string;
    get description(): string;
    get faasname(): string;
    get faasnamespace(): string;
    get guardrailUuid(): string;
    get name(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsFunctionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsFunctionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsKnowledgeBases {
}
export declare function dataDigitaloceanGenaiAgentsAgentsKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsKnowledgeBases): any;
export declare function dataDigitaloceanGenaiAgentsAgentsKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsKnowledgeBases): any;
export declare class DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktf.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsModelAgreement {
}
export declare function dataDigitaloceanGenaiAgentsAgentsModelAgreementToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsModelAgreement): any;
export declare function dataDigitaloceanGenaiAgentsAgentsModelAgreementToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsModelAgreement): any;
export declare class DataDigitaloceanGenaiAgentsAgentsModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsModelAgreementOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsModelVersions {
}
export declare function dataDigitaloceanGenaiAgentsAgentsModelVersionsToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsModelVersions): any;
export declare function dataDigitaloceanGenaiAgentsAgentsModelVersionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsModelVersions): any;
export declare class DataDigitaloceanGenaiAgentsAgentsModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGenaiAgentsAgentsModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsModelVersionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsModel {
}
export declare function dataDigitaloceanGenaiAgentsAgentsModelToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsModel): any;
export declare function dataDigitaloceanGenaiAgentsAgentsModelToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsModel): any;
export declare class DataDigitaloceanGenaiAgentsAgentsModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsModel | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGenaiAgentsAgentsModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktf.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktf.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGenaiAgentsAgentsModelVersionsList;
}
export declare class DataDigitaloceanGenaiAgentsAgentsModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsModelOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsOpenAiApiKey {
}
export declare function dataDigitaloceanGenaiAgentsAgentsOpenAiApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsOpenAiApiKey): any;
export declare function dataDigitaloceanGenaiAgentsAgentsOpenAiApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsOpenAiApiKey): any;
export declare class DataDigitaloceanGenaiAgentsAgentsOpenAiApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsOpenAiApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsOpenAiApiKey | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsOpenAiApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsOpenAiApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsParentAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsParentAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsParentAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsParentAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsParentAgents {
}
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgents): any;
export declare function dataDigitaloceanGenaiAgentsAgentsParentAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsParentAgents): any;
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsParentAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsParentAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentsAgentsParentAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentsAgentsParentAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentsAgentsParentAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentsAgentsParentAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsParentAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsParentAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob {
}
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJob | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBases {
}
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBases): any;
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBases): any;
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBases | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBases | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    get databaseId(): string;
    get embeddingModelUuid(): string;
    get isPublic(): cdktf.IResolvable;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesLastIndexingJobList;
    get name(): string;
    get projectId(): string;
    get region(): string;
    get tags(): string[];
    get updatedAt(): string;
    get userId(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreement {
}
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateModelAgreementToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreement): any;
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateModelAgreementToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreement): any;
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreement | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreement | undefined);
    get description(): string;
    get name(): string;
    get url(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreementOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsTemplateModelVersions {
}
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateModelVersionsToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateModelVersions): any;
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateModelVersionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateModelVersions): any;
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsTemplateModelVersions | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsTemplateModelVersions | undefined);
    get major(): number;
    get minor(): number;
    get patch(): number;
}
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsTemplateModelVersionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsTemplateModel {
}
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateModelToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateModel): any;
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateModelToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplateModel): any;
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsTemplateModel | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsTemplateModel | undefined);
    private _agreement;
    get agreement(): DataDigitaloceanGenaiAgentsAgentsTemplateModelAgreementList;
    get createdAt(): string;
    get inferenceName(): string;
    get inferenceVersion(): string;
    get isFoundational(): cdktf.IResolvable;
    get name(): string;
    get parentUuid(): string;
    get provider(): string;
    get updatedAt(): string;
    get uploadComplete(): cdktf.IResolvable;
    get url(): string;
    get usecases(): string[];
    private _versions;
    get versions(): DataDigitaloceanGenaiAgentsAgentsTemplateModelVersionsList;
}
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsTemplateModelOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgentsTemplate {
}
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateToTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplate): any;
export declare function dataDigitaloceanGenaiAgentsAgentsTemplateToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgentsTemplate): any;
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgentsTemplate | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgentsTemplate | undefined);
    get createdAt(): string;
    get description(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGenaiAgentsAgentsTemplateKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGenaiAgentsAgentsTemplateModelList;
    get name(): string;
    get temperature(): number;
    get topP(): number;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsTemplateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsTemplateOutputReference;
}
export interface DataDigitaloceanGenaiAgentsAgents {
}
export declare function dataDigitaloceanGenaiAgentsAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentsAgents): any;
export declare function dataDigitaloceanGenaiAgentsAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentsAgents): any;
export declare class DataDigitaloceanGenaiAgentsAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsAgents | undefined);
    private _agentGuardrail;
    get agentGuardrail(): DataDigitaloceanGenaiAgentsAgentsAgentGuardrailList;
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentsAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentsAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentsAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentsAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentsAgentsChatbotIdentifiersList;
    private _childAgents;
    get childAgents(): DataDigitaloceanGenaiAgentsAgentsChildAgentsList;
    get createdAt(): string;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentsAgentsDeploymentList;
    get description(): string;
    private _functions;
    get functions(): DataDigitaloceanGenaiAgentsAgentsFunctionsList;
    get ifCase(): string;
    get instruction(): string;
    get k(): number;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGenaiAgentsAgentsKnowledgeBasesList;
    get maxTokens(): number;
    private _model;
    get model(): DataDigitaloceanGenaiAgentsAgentsModelList;
    get modelUuid(): string;
    get name(): string;
    private _openAiApiKey;
    get openAiApiKey(): DataDigitaloceanGenaiAgentsAgentsOpenAiApiKeyList;
    private _parentAgents;
    get parentAgents(): DataDigitaloceanGenaiAgentsAgentsParentAgentsList;
    get projectId(): string;
    get region(): string;
    get retrievalMethod(): string;
    get routeCreatedAt(): string;
    get routeCreatedBy(): string;
    get routeName(): string;
    get routeUuid(): string;
    get tags(): string[];
    get temperature(): number;
    private _template;
    get template(): DataDigitaloceanGenaiAgentsAgentsTemplateList;
    get topP(): number;
    get updatedAt(): string;
    get url(): string;
    get userId(): string;
}
export declare class DataDigitaloceanGenaiAgentsAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentsFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#all DataDigitaloceanGenaiAgents#all}
    */
    readonly all?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#key DataDigitaloceanGenaiAgents#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#match_by DataDigitaloceanGenaiAgents#match_by}
    */
    readonly matchBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#values DataDigitaloceanGenaiAgents#values}
    */
    readonly values: string[];
}
export declare function dataDigitaloceanGenaiAgentsFilterToTerraform(struct?: DataDigitaloceanGenaiAgentsFilter | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentsFilterToHclTerraform(struct?: DataDigitaloceanGenaiAgentsFilter | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentsFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsFilter | cdktf.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktf.IResolvable;
    set all(value: boolean | cdktf.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktf.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchBy?;
    get matchBy(): string;
    set matchBy(value: string);
    resetMatchBy(): void;
    get matchByInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataDigitaloceanGenaiAgentsFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentsFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsFilterOutputReference;
}
export interface DataDigitaloceanGenaiAgentsSort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#direction DataDigitaloceanGenaiAgents#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#key DataDigitaloceanGenaiAgents#key}
    */
    readonly key: string;
}
export declare function dataDigitaloceanGenaiAgentsSortToTerraform(struct?: DataDigitaloceanGenaiAgentsSort | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentsSortToHclTerraform(struct?: DataDigitaloceanGenaiAgentsSort | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentsSortOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentsSort | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentsSort | cdktf.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentsSortList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentsSort[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentsSortOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents digitalocean_genai_agents}
*/
export declare class DataDigitaloceanGenaiAgents extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_agents";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiAgents resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiAgents to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiAgents that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiAgents to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agents digitalocean_genai_agents} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiAgentsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDigitaloceanGenaiAgentsConfig);
    private _agents;
    get agents(): DataDigitaloceanGenaiAgentsAgentsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _onlyDeployed?;
    get onlyDeployed(): boolean | cdktf.IResolvable;
    set onlyDeployed(value: boolean | cdktf.IResolvable);
    resetOnlyDeployed(): void;
    get onlyDeployedInput(): boolean | cdktf.IResolvable | undefined;
    private _filter;
    get filter(): DataDigitaloceanGenaiAgentsFilterList;
    putFilter(value: DataDigitaloceanGenaiAgentsFilter[] | cdktf.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentsFilter[] | undefined;
    private _sort;
    get sort(): DataDigitaloceanGenaiAgentsSortList;
    putSort(value: DataDigitaloceanGenaiAgentsSort[] | cdktf.IResolvable): void;
    resetSort(): void;
    get sortInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentsSort[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
