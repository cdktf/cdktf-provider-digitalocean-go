/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiKnowledgeBaseIndexingJobsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_indexing_jobs#id DataDigitaloceanGenaiKnowledgeBaseIndexingJobs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_indexing_jobs#knowledge_base_uuid DataDigitaloceanGenaiKnowledgeBaseIndexingJobs#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid: string;
}
export interface DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobs {
}
export declare function dataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobsToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobs): any;
export declare function dataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobsToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobs): any;
export declare class DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobs | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobs | undefined);
    get completedDatasources(): number;
    get createdAt(): string;
    get dataSourceUuids(): string[];
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    get phase(): string;
    get startedAt(): string;
    get status(): string;
    get tokens(): number;
    get totalDatasources(): number;
    get totalItemsFailed(): string;
    get totalItemsIndexed(): string;
    get totalItemsSkipped(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobsOutputReference;
}
export interface DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMeta {
}
export declare function dataDigitaloceanGenaiKnowledgeBaseIndexingJobsMetaToTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMeta): any;
export declare function dataDigitaloceanGenaiKnowledgeBaseIndexingJobsMetaToHclTerraform(struct?: DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMeta): any;
export declare class DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMetaOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMeta | undefined;
    set internalValue(value: DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMeta | undefined);
    get page(): number;
    get pages(): number;
    get total(): number;
}
export declare class DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMetaList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMetaOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_indexing_jobs digitalocean_genai_knowledge_base_indexing_jobs}
*/
export declare class DataDigitaloceanGenaiKnowledgeBaseIndexingJobs extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_knowledge_base_indexing_jobs";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiKnowledgeBaseIndexingJobs resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiKnowledgeBaseIndexingJobs to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiKnowledgeBaseIndexingJobs that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_indexing_jobs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiKnowledgeBaseIndexingJobs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_knowledge_base_indexing_jobs digitalocean_genai_knowledge_base_indexing_jobs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiKnowledgeBaseIndexingJobsConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGenaiKnowledgeBaseIndexingJobsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobs;
    get jobs(): DataDigitaloceanGenaiKnowledgeBaseIndexingJobsJobsList;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string;
    set knowledgeBaseUuid(value: string);
    get knowledgeBaseUuidInput(): string | undefined;
    private _meta;
    get meta(): DataDigitaloceanGenaiKnowledgeBaseIndexingJobsMetaList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
