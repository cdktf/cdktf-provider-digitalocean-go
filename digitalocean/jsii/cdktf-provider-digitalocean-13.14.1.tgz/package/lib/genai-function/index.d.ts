/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GenaiFunctionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the GenAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#agent_id GenaiFunction#agent_id}
    */
    readonly agentId: string;
    /**
    * The region where the GenAI resource will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#description GenaiFunction#description}
    */
    readonly description: string;
    /**
    * The model to use for the GenAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#faas_name GenaiFunction#faas_name}
    */
    readonly faasName?: string;
    /**
    * The current status of the GenAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#faas_namespace GenaiFunction#faas_namespace}
    */
    readonly faasNamespace: string;
    /**
    * The creation timestamp of the GenAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#function_name GenaiFunction#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#id GenaiFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The input schema of the GenAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#input_schema GenaiFunction#input_schema}
    */
    readonly inputSchema: string;
    /**
    * The output schema of the GenAI resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#output_schema GenaiFunction#output_schema}
    */
    readonly outputSchema?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function digitalocean_genai_function}
*/
export declare class GenaiFunction extends cdktf.TerraformResource {
    static readonly tfResourceType = "digitalocean_genai_function";
    /**
    * Generates CDKTF code for importing a GenaiFunction resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenaiFunction to import
    * @param importFromId The id of the existing GenaiFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenaiFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_function digitalocean_genai_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenaiFunctionConfig
    */
    constructor(scope: Construct, id: string, config: GenaiFunctionConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _faasName?;
    get faasName(): string;
    set faasName(value: string);
    resetFaasName(): void;
    get faasNameInput(): string | undefined;
    private _faasNamespace?;
    get faasNamespace(): string;
    set faasNamespace(value: string);
    get faasNamespaceInput(): string | undefined;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    get functionUuid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputSchema?;
    get inputSchema(): string;
    set inputSchema(value: string);
    get inputSchemaInput(): string | undefined;
    private _outputSchema?;
    get outputSchema(): string;
    set outputSchema(value: string);
    resetOutputSchema(): void;
    get outputSchemaInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
