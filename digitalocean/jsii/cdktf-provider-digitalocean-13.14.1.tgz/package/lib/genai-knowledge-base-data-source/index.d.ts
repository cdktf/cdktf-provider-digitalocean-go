/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GenaiKnowledgeBaseDataSourceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#id GenaiKnowledgeBaseDataSource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#knowledge_base_uuid GenaiKnowledgeBaseDataSource#knowledge_base_uuid}
    */
    readonly knowledgeBaseUuid: string;
    /**
    * spaces_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#spaces_data_source GenaiKnowledgeBaseDataSource#spaces_data_source}
    */
    readonly spacesDataSource?: GenaiKnowledgeBaseDataSourceSpacesDataSource;
    /**
    * web_crawler_data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#web_crawler_data_source GenaiKnowledgeBaseDataSource#web_crawler_data_source}
    */
    readonly webCrawlerDataSource?: GenaiKnowledgeBaseDataSourceWebCrawlerDataSource;
}
export interface GenaiKnowledgeBaseDataSourceSpacesDataSource {
    /**
    * The name of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#bucket_name GenaiKnowledgeBaseDataSource#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * The path to the item in the bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#item_path GenaiKnowledgeBaseDataSource#item_path}
    */
    readonly itemPath?: string;
    /**
    * The region of the Spaces bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#region GenaiKnowledgeBaseDataSource#region}
    */
    readonly region?: string;
}
export declare function genaiKnowledgeBaseDataSourceSpacesDataSourceToTerraform(struct?: GenaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference | GenaiKnowledgeBaseDataSourceSpacesDataSource): any;
export declare function genaiKnowledgeBaseDataSourceSpacesDataSourceToHclTerraform(struct?: GenaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference | GenaiKnowledgeBaseDataSourceSpacesDataSource): any;
export declare class GenaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenaiKnowledgeBaseDataSourceSpacesDataSource | undefined;
    set internalValue(value: GenaiKnowledgeBaseDataSourceSpacesDataSource | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _itemPath?;
    get itemPath(): string;
    set itemPath(value: string);
    resetItemPath(): void;
    get itemPathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface GenaiKnowledgeBaseDataSourceWebCrawlerDataSource {
    /**
    * The base URL to crawl
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#base_url GenaiKnowledgeBaseDataSource#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Options for specifying how URLs found on pages should be handled.
    * - UNKNOWN: Default unknown value
    * - SCOPED: Only include the base URL.
    * - PATH: Crawl the base URL and linked pages within the URL path.
    * - DOMAIN: Crawl the base URL and linked pages within the same domain.
    * - SUBDOMAINS: Crawl the base URL and linked pages for any subdomain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#crawling_option GenaiKnowledgeBaseDataSource#crawling_option}
    */
    readonly crawlingOption?: string;
    /**
    * Whether to embed media content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#embed_media GenaiKnowledgeBaseDataSource#embed_media}
    */
    readonly embedMedia?: boolean | cdktf.IResolvable;
}
export declare function genaiKnowledgeBaseDataSourceWebCrawlerDataSourceToTerraform(struct?: GenaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference | GenaiKnowledgeBaseDataSourceWebCrawlerDataSource): any;
export declare function genaiKnowledgeBaseDataSourceWebCrawlerDataSourceToHclTerraform(struct?: GenaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference | GenaiKnowledgeBaseDataSourceWebCrawlerDataSource): any;
export declare class GenaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenaiKnowledgeBaseDataSourceWebCrawlerDataSource | undefined;
    set internalValue(value: GenaiKnowledgeBaseDataSourceWebCrawlerDataSource | undefined);
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _crawlingOption?;
    get crawlingOption(): string;
    set crawlingOption(value: string);
    resetCrawlingOption(): void;
    get crawlingOptionInput(): string | undefined;
    private _embedMedia?;
    get embedMedia(): boolean | cdktf.IResolvable;
    set embedMedia(value: boolean | cdktf.IResolvable);
    resetEmbedMedia(): void;
    get embedMediaInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source digitalocean_genai_knowledge_base_data_source}
*/
export declare class GenaiKnowledgeBaseDataSource extends cdktf.TerraformResource {
    static readonly tfResourceType = "digitalocean_genai_knowledge_base_data_source";
    /**
    * Generates CDKTF code for importing a GenaiKnowledgeBaseDataSource resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenaiKnowledgeBaseDataSource to import
    * @param importFromId The id of the existing GenaiKnowledgeBaseDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenaiKnowledgeBaseDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/resources/genai_knowledge_base_data_source digitalocean_genai_knowledge_base_data_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenaiKnowledgeBaseDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: GenaiKnowledgeBaseDataSourceConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knowledgeBaseUuid?;
    get knowledgeBaseUuid(): string;
    set knowledgeBaseUuid(value: string);
    get knowledgeBaseUuidInput(): string | undefined;
    private _spacesDataSource;
    get spacesDataSource(): GenaiKnowledgeBaseDataSourceSpacesDataSourceOutputReference;
    putSpacesDataSource(value: GenaiKnowledgeBaseDataSourceSpacesDataSource): void;
    resetSpacesDataSource(): void;
    get spacesDataSourceInput(): GenaiKnowledgeBaseDataSourceSpacesDataSource | undefined;
    private _webCrawlerDataSource;
    get webCrawlerDataSource(): GenaiKnowledgeBaseDataSourceWebCrawlerDataSourceOutputReference;
    putWebCrawlerDataSource(value: GenaiKnowledgeBaseDataSourceWebCrawlerDataSource): void;
    resetWebCrawlerDataSource(): void;
    get webCrawlerDataSourceInput(): GenaiKnowledgeBaseDataSourceWebCrawlerDataSource | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
