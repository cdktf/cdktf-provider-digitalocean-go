/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiAgentConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Agent to retrieve
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#agent_id DataDigitaloceanGenaiAgent#agent_id}
    */
    readonly agentId: string;
    /**
    * Description for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#description DataDigitaloceanGenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#id DataDigitaloceanGenaiAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If case condition
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#if_case DataDigitaloceanGenaiAgent#if_case}
    */
    readonly ifCase?: string;
    /**
    * K value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#k DataDigitaloceanGenaiAgent#k}
    */
    readonly k?: number;
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#max_tokens DataDigitaloceanGenaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Retrieval method used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#retrieval_method DataDigitaloceanGenaiAgent#retrieval_method}
    */
    readonly retrievalMethod?: string;
    /**
    * User who created the route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#route_created_by DataDigitaloceanGenaiAgent#route_created_by}
    */
    readonly routeCreatedBy?: string;
    /**
    * Route name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#route_name DataDigitaloceanGenaiAgent#route_name}
    */
    readonly routeName?: string;
    /**
    * Route UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#route_uuid DataDigitaloceanGenaiAgent#route_uuid}
    */
    readonly routeUuid?: string;
    /**
    * List of Tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#tags DataDigitaloceanGenaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#temperature DataDigitaloceanGenaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#top_p DataDigitaloceanGenaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * URL for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#url DataDigitaloceanGenaiAgent#url}
    */
    readonly url?: string;
    /**
    * User ID linked with the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#user_id DataDigitaloceanGenaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * agent_guardrail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#agent_guardrail DataDigitaloceanGenaiAgent#agent_guardrail}
    */
    readonly agentGuardrail?: DataDigitaloceanGenaiAgentAgentGuardrail[] | cdktf.IResolvable;
    /**
    * anthropic_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#anthropic_api_key DataDigitaloceanGenaiAgent#anthropic_api_key}
    */
    readonly anthropicApiKey?: DataDigitaloceanGenaiAgentAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * api_key_infos block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#api_key_infos DataDigitaloceanGenaiAgent#api_key_infos}
    */
    readonly apiKeyInfos?: DataDigitaloceanGenaiAgentApiKeyInfos[] | cdktf.IResolvable;
    /**
    * api_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#api_keys DataDigitaloceanGenaiAgent#api_keys}
    */
    readonly apiKeys?: DataDigitaloceanGenaiAgentApiKeys[] | cdktf.IResolvable;
    /**
    * chatbot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#chatbot DataDigitaloceanGenaiAgent#chatbot}
    */
    readonly chatbot?: DataDigitaloceanGenaiAgentChatbot[] | cdktf.IResolvable;
    /**
    * chatbot_identifiers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#chatbot_identifiers DataDigitaloceanGenaiAgent#chatbot_identifiers}
    */
    readonly chatbotIdentifiers?: DataDigitaloceanGenaiAgentChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#deployment DataDigitaloceanGenaiAgent#deployment}
    */
    readonly deployment?: DataDigitaloceanGenaiAgentDeployment[] | cdktf.IResolvable;
    /**
    * functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#functions DataDigitaloceanGenaiAgent#functions}
    */
    readonly functions?: DataDigitaloceanGenaiAgentFunctions[] | cdktf.IResolvable;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#knowledge_bases DataDigitaloceanGenaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: DataDigitaloceanGenaiAgentKnowledgeBases[] | cdktf.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#model DataDigitaloceanGenaiAgent#model}
    */
    readonly model?: DataDigitaloceanGenaiAgentModel[] | cdktf.IResolvable;
    /**
    * open_ai_api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#open_ai_api_key DataDigitaloceanGenaiAgent#open_ai_api_key}
    */
    readonly openAiApiKey?: DataDigitaloceanGenaiAgentOpenAiApiKey[] | cdktf.IResolvable;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#template DataDigitaloceanGenaiAgent#template}
    */
    readonly template?: DataDigitaloceanGenaiAgentTemplate[] | cdktf.IResolvable;
}
export interface DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentChildAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentChildAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentChildAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentChildAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentChildAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentChildAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChildAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChildAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentChildAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChildAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentChildAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentChildAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentChildAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentChildAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChildAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChildAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentChildAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChildAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentChildAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentChildAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentChildAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentChildAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChildAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChildAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentChildAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChildAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentChildAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentChildAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentChildAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentChildAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentChildAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChildAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChildAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentChildAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChildAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentChildAgents {
}
export declare function dataDigitaloceanGenaiAgentChildAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentChildAgents): any;
export declare function dataDigitaloceanGenaiAgentChildAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentChildAgents): any;
export declare class DataDigitaloceanGenaiAgentChildAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChildAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChildAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentChildAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentChildAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentChildAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentChildAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentChildAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentChildAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGenaiAgentChildAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChildAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKey {
}
export declare function dataDigitaloceanGenaiAgentParentAgentsAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKey): any;
export declare function dataDigitaloceanGenaiAgentParentAgentsAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKey): any;
export declare class DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKey | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKey | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get updatedAt(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentParentAgentsApiKeyInfos {
}
export declare function dataDigitaloceanGenaiAgentParentAgentsApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsApiKeyInfos): any;
export declare function dataDigitaloceanGenaiAgentParentAgentsApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsApiKeyInfos): any;
export declare class DataDigitaloceanGenaiAgentParentAgentsApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentParentAgentsApiKeyInfos | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentParentAgentsApiKeyInfos | undefined);
    get createdAt(): string;
    get createdBy(): string;
    get deletedAt(): string;
    get name(): string;
    get secretKey(): string;
    get uuid(): string;
}
export declare class DataDigitaloceanGenaiAgentParentAgentsApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentParentAgentsApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentParentAgentsApiKeys {
}
export declare function dataDigitaloceanGenaiAgentParentAgentsApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsApiKeys): any;
export declare function dataDigitaloceanGenaiAgentParentAgentsApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsApiKeys): any;
export declare class DataDigitaloceanGenaiAgentParentAgentsApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentParentAgentsApiKeys | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentParentAgentsApiKeys | undefined);
    get apiKey(): string;
}
export declare class DataDigitaloceanGenaiAgentParentAgentsApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentParentAgentsApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentParentAgentsChatbot {
}
export declare function dataDigitaloceanGenaiAgentParentAgentsChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsChatbot): any;
export declare function dataDigitaloceanGenaiAgentParentAgentsChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsChatbot): any;
export declare class DataDigitaloceanGenaiAgentParentAgentsChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentParentAgentsChatbot | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentParentAgentsChatbot | undefined);
    get buttonBackgroundColor(): string;
    get logo(): string;
    get name(): string;
    get primaryColor(): string;
    get secondaryColor(): string;
    get startingMessage(): string;
}
export declare class DataDigitaloceanGenaiAgentParentAgentsChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentParentAgentsChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiers {
}
export declare function dataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiers): any;
export declare function dataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiers): any;
export declare class DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiers | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiers | undefined);
    get chatbotId(): string;
}
export declare class DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentParentAgentsDeployment {
}
export declare function dataDigitaloceanGenaiAgentParentAgentsDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsDeployment): any;
export declare function dataDigitaloceanGenaiAgentParentAgentsDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentParentAgentsDeployment): any;
export declare class DataDigitaloceanGenaiAgentParentAgentsDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentParentAgentsDeployment | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentParentAgentsDeployment | undefined);
    get createdAt(): string;
    get name(): string;
    get status(): string;
    get updatedAt(): string;
    get url(): string;
    get uuid(): string;
    get visibility(): string;
}
export declare class DataDigitaloceanGenaiAgentParentAgentsDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentParentAgentsDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentParentAgents {
}
export declare function dataDigitaloceanGenaiAgentParentAgentsToTerraform(struct?: DataDigitaloceanGenaiAgentParentAgents): any;
export declare function dataDigitaloceanGenaiAgentParentAgentsToHclTerraform(struct?: DataDigitaloceanGenaiAgentParentAgents): any;
export declare class DataDigitaloceanGenaiAgentParentAgentsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentParentAgents | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentParentAgents | undefined);
    get agentId(): string;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentParentAgentsAnthropicApiKeyList;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentParentAgentsApiKeyInfosList;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentParentAgentsApiKeysList;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentParentAgentsChatbotList;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentParentAgentsChatbotIdentifiersList;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentParentAgentsDeploymentList;
    get description(): string;
    get instruction(): string;
    get modelUuid(): string;
    get name(): string;
    get projectId(): string;
    get region(): string;
}
export declare class DataDigitaloceanGenaiAgentParentAgentsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentParentAgentsOutputReference;
}
export interface DataDigitaloceanGenaiAgentAgentGuardrail {
    /**
    * Agent UUID for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#agent_uuid DataDigitaloceanGenaiAgent#agent_uuid}
    */
    readonly agentUuid?: string;
    /**
    * Default response for the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#default_response DataDigitaloceanGenaiAgent#default_response}
    */
    readonly defaultResponse?: string;
    /**
    * Description of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#description DataDigitaloceanGenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#guardrail_uuid DataDigitaloceanGenaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Indicates if the Guardrail is default
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#is_default DataDigitaloceanGenaiAgent#is_default}
    */
    readonly isDefault?: boolean | cdktf.IResolvable;
    /**
    * Name of Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Priority of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#priority DataDigitaloceanGenaiAgent#priority}
    */
    readonly priority?: number;
    /**
    * Type of the Guardrail
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#type DataDigitaloceanGenaiAgent#type}
    */
    readonly type?: string;
    /**
    * Guardrail UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentAgentGuardrailToTerraform(struct?: DataDigitaloceanGenaiAgentAgentGuardrail | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentAgentGuardrailToHclTerraform(struct?: DataDigitaloceanGenaiAgentAgentGuardrail | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentAgentGuardrailOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentAgentGuardrail | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentAgentGuardrail | cdktf.IResolvable | undefined);
    private _agentUuid?;
    get agentUuid(): string;
    set agentUuid(value: string);
    resetAgentUuid(): void;
    get agentUuidInput(): string | undefined;
    get createdAt(): string;
    private _defaultResponse?;
    get defaultResponse(): string;
    set defaultResponse(value: string);
    resetDefaultResponse(): void;
    get defaultResponseInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    get isAttached(): cdktf.IResolvable;
    private _isDefault?;
    get isDefault(): boolean | cdktf.IResolvable;
    set isDefault(value: boolean | cdktf.IResolvable);
    resetIsDefault(): void;
    get isDefaultInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentAgentGuardrailList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentAgentGuardrail[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentAgentGuardrailOutputReference;
}
export interface DataDigitaloceanGenaiAgentAnthropicApiKey {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#created_by DataDigitaloceanGenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentAnthropicApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentAnthropicApiKey | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentAnthropicApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentAnthropicApiKey | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentAnthropicApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentAnthropicApiKey | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentAnthropicApiKey | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentAnthropicApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentAnthropicApiKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentAnthropicApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentApiKeyInfos {
    /**
    * Created By user ID for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#created_by DataDigitaloceanGenaiAgent#created_by}
    */
    readonly createdBy?: string;
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Updated At timestamp for the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#secret_key DataDigitaloceanGenaiAgent#secret_key}
    */
    readonly secretKey?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentApiKeyInfosToTerraform(struct?: DataDigitaloceanGenaiAgentApiKeyInfos | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentApiKeyInfosToHclTerraform(struct?: DataDigitaloceanGenaiAgentApiKeyInfos | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentApiKeyInfosOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentApiKeyInfos | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentApiKeyInfos | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get deletedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentApiKeyInfosList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentApiKeyInfos[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentApiKeyInfosOutputReference;
}
export interface DataDigitaloceanGenaiAgentApiKeys {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#api_key DataDigitaloceanGenaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function dataDigitaloceanGenaiAgentApiKeysToTerraform(struct?: DataDigitaloceanGenaiAgentApiKeys | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentApiKeysToHclTerraform(struct?: DataDigitaloceanGenaiAgentApiKeys | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentApiKeysOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentApiKeys | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentApiKeys | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentApiKeysList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentApiKeys[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentApiKeysOutputReference;
}
export interface DataDigitaloceanGenaiAgentChatbot {
    /**
    * Background color for the chatbot button
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#button_background_color DataDigitaloceanGenaiAgent#button_background_color}
    */
    readonly buttonBackgroundColor?: string;
    /**
    * Logo for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#logo DataDigitaloceanGenaiAgent#logo}
    */
    readonly logo?: string;
    /**
    * Name of the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Primary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#primary_color DataDigitaloceanGenaiAgent#primary_color}
    */
    readonly primaryColor?: string;
    /**
    * Secondary color for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#secondary_color DataDigitaloceanGenaiAgent#secondary_color}
    */
    readonly secondaryColor?: string;
    /**
    * Starting message for the chatbot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#starting_message DataDigitaloceanGenaiAgent#starting_message}
    */
    readonly startingMessage?: string;
}
export declare function dataDigitaloceanGenaiAgentChatbotToTerraform(struct?: DataDigitaloceanGenaiAgentChatbot | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentChatbotToHclTerraform(struct?: DataDigitaloceanGenaiAgentChatbot | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentChatbotOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChatbot | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChatbot | cdktf.IResolvable | undefined);
    private _buttonBackgroundColor?;
    get buttonBackgroundColor(): string;
    set buttonBackgroundColor(value: string);
    resetButtonBackgroundColor(): void;
    get buttonBackgroundColorInput(): string | undefined;
    private _logo?;
    get logo(): string;
    set logo(value: string);
    resetLogo(): void;
    get logoInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _primaryColor?;
    get primaryColor(): string;
    set primaryColor(value: string);
    resetPrimaryColor(): void;
    get primaryColorInput(): string | undefined;
    private _secondaryColor?;
    get secondaryColor(): string;
    set secondaryColor(value: string);
    resetSecondaryColor(): void;
    get secondaryColorInput(): string | undefined;
    private _startingMessage?;
    get startingMessage(): string;
    set startingMessage(value: string);
    resetStartingMessage(): void;
    get startingMessageInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentChatbotList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentChatbot[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChatbotOutputReference;
}
export interface DataDigitaloceanGenaiAgentChatbotIdentifiers {
    /**
    * Chatbot ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#chatbot_id DataDigitaloceanGenaiAgent#chatbot_id}
    */
    readonly chatbotId?: string;
}
export declare function dataDigitaloceanGenaiAgentChatbotIdentifiersToTerraform(struct?: DataDigitaloceanGenaiAgentChatbotIdentifiers | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentChatbotIdentifiersToHclTerraform(struct?: DataDigitaloceanGenaiAgentChatbotIdentifiers | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentChatbotIdentifiersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentChatbotIdentifiers | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentChatbotIdentifiers | cdktf.IResolvable | undefined);
    private _chatbotId?;
    get chatbotId(): string;
    set chatbotId(value: string);
    resetChatbotId(): void;
    get chatbotIdInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentChatbotIdentifiersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentChatbotIdentifiers[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentChatbotIdentifiersOutputReference;
}
export interface DataDigitaloceanGenaiAgentDeployment {
    /**
    * Name of the API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Status of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#status DataDigitaloceanGenaiAgent#status}
    */
    readonly status?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#url DataDigitaloceanGenaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * Visibility of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#visibility DataDigitaloceanGenaiAgent#visibility}
    */
    readonly visibility?: string;
}
export declare function dataDigitaloceanGenaiAgentDeploymentToTerraform(struct?: DataDigitaloceanGenaiAgentDeployment | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentDeploymentToHclTerraform(struct?: DataDigitaloceanGenaiAgentDeployment | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentDeploymentOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentDeployment | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentDeployment | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentDeploymentList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentDeployment[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentDeploymentOutputReference;
}
export interface DataDigitaloceanGenaiAgentFunctions {
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#api_key DataDigitaloceanGenaiAgent#api_key}
    */
    readonly apiKey?: string;
    /**
    * Description of the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#description DataDigitaloceanGenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#faasname DataDigitaloceanGenaiAgent#faasname}
    */
    readonly faasname?: string;
    /**
    * Namespace of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#faasnamespace DataDigitaloceanGenaiAgent#faasnamespace}
    */
    readonly faasnamespace?: string;
    /**
    * Guardrail UUID for the Function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#guardrail_uuid DataDigitaloceanGenaiAgent#guardrail_uuid}
    */
    readonly guardrailUuid?: string;
    /**
    * Name of function
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Url of the Deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#url DataDigitaloceanGenaiAgent#url}
    */
    readonly url?: string;
    /**
    * API Key value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentFunctionsToTerraform(struct?: DataDigitaloceanGenaiAgentFunctions | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentFunctionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentFunctions | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentFunctionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentFunctions | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentFunctions | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _faasname?;
    get faasname(): string;
    set faasname(value: string);
    resetFaasname(): void;
    get faasnameInput(): string | undefined;
    private _faasnamespace?;
    get faasnamespace(): string;
    set faasnamespace(value: string);
    resetFaasnamespace(): void;
    get faasnamespaceInput(): string | undefined;
    private _guardrailUuid?;
    get guardrailUuid(): string;
    set guardrailUuid(value: string);
    resetGuardrailUuid(): void;
    get guardrailUuidInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentFunctionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentFunctions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentFunctionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#completed_datasources DataDigitaloceanGenaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#data_source_uuids DataDigitaloceanGenaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#phase DataDigitaloceanGenaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#tokens DataDigitaloceanGenaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#total_datasources DataDigitaloceanGenaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface DataDigitaloceanGenaiAgentKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#database_id DataDigitaloceanGenaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#embedding_model_uuid DataDigitaloceanGenaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#is_public DataDigitaloceanGenaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#project_id DataDigitaloceanGenaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#region DataDigitaloceanGenaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#tags DataDigitaloceanGenaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#user_id DataDigitaloceanGenaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#last_indexing_job DataDigitaloceanGenaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob;
}
export declare function dataDigitaloceanGenaiAgentKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiAgentKnowledgeBases | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiAgentKnowledgeBases | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentKnowledgeBases | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentKnowledgeBases | cdktf.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktf.IResolvable;
    set isPublic(value: boolean | cdktf.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): DataDigitaloceanGenaiAgentKnowledgeBasesLastIndexingJob | undefined;
}
export declare class DataDigitaloceanGenaiAgentKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentKnowledgeBases[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiAgentModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#description DataDigitaloceanGenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#url DataDigitaloceanGenaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentModelAgreementToTerraform(struct?: DataDigitaloceanGenaiAgentModelAgreement | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentModelAgreementToHclTerraform(struct?: DataDigitaloceanGenaiAgentModelAgreement | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentModelAgreement | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentModelAgreement | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentModelAgreement[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentModelAgreementOutputReference;
}
export interface DataDigitaloceanGenaiAgentModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#major DataDigitaloceanGenaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#minor DataDigitaloceanGenaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#patch DataDigitaloceanGenaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function dataDigitaloceanGenaiAgentModelVersionsToTerraform(struct?: DataDigitaloceanGenaiAgentModelVersions | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentModelVersionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentModelVersions | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentModelVersions | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentModelVersions | cdktf.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class DataDigitaloceanGenaiAgentModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentModelVersions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentModelVersionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#inference_name DataDigitaloceanGenaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#inference_version DataDigitaloceanGenaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#is_foundational DataDigitaloceanGenaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#parent_uuid DataDigitaloceanGenaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#provider DataDigitaloceanGenaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#upload_complete DataDigitaloceanGenaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktf.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#url DataDigitaloceanGenaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#usecases DataDigitaloceanGenaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#agreement DataDigitaloceanGenaiAgent#agreement}
    */
    readonly agreement?: DataDigitaloceanGenaiAgentModelAgreement[] | cdktf.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#versions DataDigitaloceanGenaiAgent#versions}
    */
    readonly versions?: DataDigitaloceanGenaiAgentModelVersions[] | cdktf.IResolvable;
}
export declare function dataDigitaloceanGenaiAgentModelToTerraform(struct?: DataDigitaloceanGenaiAgentModel | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentModelToHclTerraform(struct?: DataDigitaloceanGenaiAgentModel | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentModel | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentModel | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktf.IResolvable;
    set isFoundational(value: boolean | cdktf.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktf.IResolvable;
    set uploadComplete(value: boolean | cdktf.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktf.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): DataDigitaloceanGenaiAgentModelAgreementList;
    putAgreement(value: DataDigitaloceanGenaiAgentModelAgreement[] | cdktf.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentModelAgreement[] | undefined;
    private _versions;
    get versions(): DataDigitaloceanGenaiAgentModelVersionsList;
    putVersions(value: DataDigitaloceanGenaiAgentModelVersions[] | cdktf.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentModelVersions[] | undefined;
}
export declare class DataDigitaloceanGenaiAgentModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentModel[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentModelOutputReference;
}
export interface DataDigitaloceanGenaiAgentOpenAiApiKey {
    /**
    * OpenAI API Key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#api_key DataDigitaloceanGenaiAgent#api_key}
    */
    readonly apiKey?: string;
}
export declare function dataDigitaloceanGenaiAgentOpenAiApiKeyToTerraform(struct?: DataDigitaloceanGenaiAgentOpenAiApiKey | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentOpenAiApiKeyToHclTerraform(struct?: DataDigitaloceanGenaiAgentOpenAiApiKey | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentOpenAiApiKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentOpenAiApiKey | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentOpenAiApiKey | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentOpenAiApiKeyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentOpenAiApiKey[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentOpenAiApiKeyOutputReference;
}
export interface DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob {
    /**
    * Number of completed datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#completed_datasources DataDigitaloceanGenaiAgent#completed_datasources}
    */
    readonly completedDatasources?: number;
    /**
    * Datasource UUIDs for the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#data_source_uuids DataDigitaloceanGenaiAgent#data_source_uuids}
    */
    readonly dataSourceUuids?: string[];
    /**
    * Phase of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#phase DataDigitaloceanGenaiAgent#phase}
    */
    readonly phase?: string;
    /**
    * Number of tokens processed in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#tokens DataDigitaloceanGenaiAgent#tokens}
    */
    readonly tokens?: number;
    /**
    * Total number of datasources in the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#total_datasources DataDigitaloceanGenaiAgent#total_datasources}
    */
    readonly totalDatasources?: number;
    /**
    * UUID  of the last indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJobToTerraform(struct?: DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare function dataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJobToHclTerraform(struct?: DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference | DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob): any;
export declare class DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined);
    private _completedDatasources?;
    get completedDatasources(): number;
    set completedDatasources(value: number);
    resetCompletedDatasources(): void;
    get completedDatasourcesInput(): number | undefined;
    get createdAt(): string;
    private _dataSourceUuids?;
    get dataSourceUuids(): string[];
    set dataSourceUuids(value: string[]);
    resetDataSourceUuids(): void;
    get dataSourceUuidsInput(): string[] | undefined;
    get finishedAt(): string;
    get knowledgeBaseUuid(): string;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    resetPhase(): void;
    get phaseInput(): string | undefined;
    get startedAt(): string;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
    private _totalDatasources?;
    get totalDatasources(): number;
    set totalDatasources(value: number);
    resetTotalDatasources(): void;
    get totalDatasourcesInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export interface DataDigitaloceanGenaiAgentTemplateKnowledgeBases {
    /**
    * Database ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#database_id DataDigitaloceanGenaiAgent#database_id}
    */
    readonly databaseId?: string;
    /**
    * Embedding model UUID for the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#embedding_model_uuid DataDigitaloceanGenaiAgent#embedding_model_uuid}
    */
    readonly embeddingModelUuid?: string;
    /**
    * Indicates if the Knowledge Base is public
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#is_public DataDigitaloceanGenaiAgent#is_public}
    */
    readonly isPublic?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Project ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#project_id DataDigitaloceanGenaiAgent#project_id}
    */
    readonly projectId?: string;
    /**
    * Region of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#region DataDigitaloceanGenaiAgent#region}
    */
    readonly region?: string;
    /**
    * List of tags
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#tags DataDigitaloceanGenaiAgent#tags}
    */
    readonly tags?: string[];
    /**
    * User ID of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#user_id DataDigitaloceanGenaiAgent#user_id}
    */
    readonly userId?: string;
    /**
    * last_indexing_job block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#last_indexing_job DataDigitaloceanGenaiAgent#last_indexing_job}
    */
    readonly lastIndexingJob?: DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob;
}
export declare function dataDigitaloceanGenaiAgentTemplateKnowledgeBasesToTerraform(struct?: DataDigitaloceanGenaiAgentTemplateKnowledgeBases | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentTemplateKnowledgeBasesToHclTerraform(struct?: DataDigitaloceanGenaiAgentTemplateKnowledgeBases | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentTemplateKnowledgeBasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentTemplateKnowledgeBases | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentTemplateKnowledgeBases | cdktf.IResolvable | undefined);
    get addedToAgentAt(): string;
    get createdAt(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    private _embeddingModelUuid?;
    get embeddingModelUuid(): string;
    set embeddingModelUuid(value: string);
    resetEmbeddingModelUuid(): void;
    get embeddingModelUuidInput(): string | undefined;
    private _isPublic?;
    get isPublic(): boolean | cdktf.IResolvable;
    set isPublic(value: boolean | cdktf.IResolvable);
    resetIsPublic(): void;
    get isPublicInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    get uuid(): string;
    private _lastIndexingJob;
    get lastIndexingJob(): DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJobOutputReference;
    putLastIndexingJob(value: DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob): void;
    resetLastIndexingJob(): void;
    get lastIndexingJobInput(): DataDigitaloceanGenaiAgentTemplateKnowledgeBasesLastIndexingJob | undefined;
}
export declare class DataDigitaloceanGenaiAgentTemplateKnowledgeBasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentTemplateKnowledgeBases[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentTemplateKnowledgeBasesOutputReference;
}
export interface DataDigitaloceanGenaiAgentTemplateModelAgreement {
    /**
    * Description of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#description DataDigitaloceanGenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Name of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * URL of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#url DataDigitaloceanGenaiAgent#url}
    */
    readonly url?: string;
    /**
    * UUID of the agreement
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
}
export declare function dataDigitaloceanGenaiAgentTemplateModelAgreementToTerraform(struct?: DataDigitaloceanGenaiAgentTemplateModelAgreement | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentTemplateModelAgreementToHclTerraform(struct?: DataDigitaloceanGenaiAgentTemplateModelAgreement | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentTemplateModelAgreementOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentTemplateModelAgreement | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentTemplateModelAgreement | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
}
export declare class DataDigitaloceanGenaiAgentTemplateModelAgreementList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentTemplateModelAgreement[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentTemplateModelAgreementOutputReference;
}
export interface DataDigitaloceanGenaiAgentTemplateModelVersions {
    /**
    * Major version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#major DataDigitaloceanGenaiAgent#major}
    */
    readonly major?: number;
    /**
    * Minor version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#minor DataDigitaloceanGenaiAgent#minor}
    */
    readonly minor?: number;
    /**
    * Patch version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#patch DataDigitaloceanGenaiAgent#patch}
    */
    readonly patch?: number;
}
export declare function dataDigitaloceanGenaiAgentTemplateModelVersionsToTerraform(struct?: DataDigitaloceanGenaiAgentTemplateModelVersions | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentTemplateModelVersionsToHclTerraform(struct?: DataDigitaloceanGenaiAgentTemplateModelVersions | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentTemplateModelVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentTemplateModelVersions | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentTemplateModelVersions | cdktf.IResolvable | undefined);
    private _major?;
    get major(): number;
    set major(value: number);
    resetMajor(): void;
    get majorInput(): number | undefined;
    private _minor?;
    get minor(): number;
    set minor(value: number);
    resetMinor(): void;
    get minorInput(): number | undefined;
    private _patch?;
    get patch(): number;
    set patch(value: number);
    resetPatch(): void;
    get patchInput(): number | undefined;
}
export declare class DataDigitaloceanGenaiAgentTemplateModelVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentTemplateModelVersions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentTemplateModelVersionsOutputReference;
}
export interface DataDigitaloceanGenaiAgentTemplateModel {
    /**
    * Inference name of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#inference_name DataDigitaloceanGenaiAgent#inference_name}
    */
    readonly inferenceName?: string;
    /**
    * Infernce version of the model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#inference_version DataDigitaloceanGenaiAgent#inference_version}
    */
    readonly inferenceVersion?: string;
    /**
    * Indicates if the Model Base is foundational
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#is_foundational DataDigitaloceanGenaiAgent#is_foundational}
    */
    readonly isFoundational?: boolean | cdktf.IResolvable;
    /**
    * Name of the Knowledge Base
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Parent UUID of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#parent_uuid DataDigitaloceanGenaiAgent#parent_uuid}
    */
    readonly parentUuid?: string;
    /**
    * Provider of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#provider DataDigitaloceanGenaiAgent#provider}
    */
    readonly provider?: string;
    /**
    * Indicates if the Model upload is complete
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#upload_complete DataDigitaloceanGenaiAgent#upload_complete}
    */
    readonly uploadComplete?: boolean | cdktf.IResolvable;
    /**
    * URL of the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#url DataDigitaloceanGenaiAgent#url}
    */
    readonly url?: string;
    /**
    * List of Usecases for the Model
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#usecases DataDigitaloceanGenaiAgent#usecases}
    */
    readonly usecases?: string[];
    /**
    * agreement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#agreement DataDigitaloceanGenaiAgent#agreement}
    */
    readonly agreement?: DataDigitaloceanGenaiAgentTemplateModelAgreement[] | cdktf.IResolvable;
    /**
    * versions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#versions DataDigitaloceanGenaiAgent#versions}
    */
    readonly versions?: DataDigitaloceanGenaiAgentTemplateModelVersions[] | cdktf.IResolvable;
}
export declare function dataDigitaloceanGenaiAgentTemplateModelToTerraform(struct?: DataDigitaloceanGenaiAgentTemplateModel | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentTemplateModelToHclTerraform(struct?: DataDigitaloceanGenaiAgentTemplateModel | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentTemplateModelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentTemplateModel | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentTemplateModel | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _inferenceName?;
    get inferenceName(): string;
    set inferenceName(value: string);
    resetInferenceName(): void;
    get inferenceNameInput(): string | undefined;
    private _inferenceVersion?;
    get inferenceVersion(): string;
    set inferenceVersion(value: string);
    resetInferenceVersion(): void;
    get inferenceVersionInput(): string | undefined;
    private _isFoundational?;
    get isFoundational(): boolean | cdktf.IResolvable;
    set isFoundational(value: boolean | cdktf.IResolvable);
    resetIsFoundational(): void;
    get isFoundationalInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentUuid?;
    get parentUuid(): string;
    set parentUuid(value: string);
    resetParentUuid(): void;
    get parentUuidInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    get updatedAt(): string;
    private _uploadComplete?;
    get uploadComplete(): boolean | cdktf.IResolvable;
    set uploadComplete(value: boolean | cdktf.IResolvable);
    resetUploadComplete(): void;
    get uploadCompleteInput(): boolean | cdktf.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usecases?;
    get usecases(): string[];
    set usecases(value: string[]);
    resetUsecases(): void;
    get usecasesInput(): string[] | undefined;
    private _agreement;
    get agreement(): DataDigitaloceanGenaiAgentTemplateModelAgreementList;
    putAgreement(value: DataDigitaloceanGenaiAgentTemplateModelAgreement[] | cdktf.IResolvable): void;
    resetAgreement(): void;
    get agreementInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentTemplateModelAgreement[] | undefined;
    private _versions;
    get versions(): DataDigitaloceanGenaiAgentTemplateModelVersionsList;
    putVersions(value: DataDigitaloceanGenaiAgentTemplateModelVersions[] | cdktf.IResolvable): void;
    resetVersions(): void;
    get versionsInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentTemplateModelVersions[] | undefined;
}
export declare class DataDigitaloceanGenaiAgentTemplateModelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentTemplateModel[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentTemplateModelOutputReference;
}
export interface DataDigitaloceanGenaiAgentTemplate {
    /**
    * Description of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#description DataDigitaloceanGenaiAgent#description}
    */
    readonly description?: string;
    /**
    * Instruction for the Agent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#instruction DataDigitaloceanGenaiAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * K value for the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#k DataDigitaloceanGenaiAgent#k}
    */
    readonly k?: number;
    /**
    * Maximum tokens allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#max_tokens DataDigitaloceanGenaiAgent#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Name of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#name DataDigitaloceanGenaiAgent#name}
    */
    readonly name?: string;
    /**
    * Agent temperature setting
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#temperature DataDigitaloceanGenaiAgent#temperature}
    */
    readonly temperature?: number;
    /**
    * Top P sampling parameter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#top_p DataDigitaloceanGenaiAgent#top_p}
    */
    readonly topP?: number;
    /**
    * uuid of the Agent Template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#uuid DataDigitaloceanGenaiAgent#uuid}
    */
    readonly uuid?: string;
    /**
    * knowledge_bases block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#knowledge_bases DataDigitaloceanGenaiAgent#knowledge_bases}
    */
    readonly knowledgeBases?: DataDigitaloceanGenaiAgentTemplateKnowledgeBases[] | cdktf.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#model DataDigitaloceanGenaiAgent#model}
    */
    readonly model?: DataDigitaloceanGenaiAgentTemplateModel[] | cdktf.IResolvable;
}
export declare function dataDigitaloceanGenaiAgentTemplateToTerraform(struct?: DataDigitaloceanGenaiAgentTemplate | cdktf.IResolvable): any;
export declare function dataDigitaloceanGenaiAgentTemplateToHclTerraform(struct?: DataDigitaloceanGenaiAgentTemplate | cdktf.IResolvable): any;
export declare class DataDigitaloceanGenaiAgentTemplateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiAgentTemplate | cdktf.IResolvable | undefined;
    set internalValue(value: DataDigitaloceanGenaiAgentTemplate | cdktf.IResolvable | undefined);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _uuid?;
    get uuid(): string;
    set uuid(value: string);
    resetUuid(): void;
    get uuidInput(): string | undefined;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGenaiAgentTemplateKnowledgeBasesList;
    putKnowledgeBases(value: DataDigitaloceanGenaiAgentTemplateKnowledgeBases[] | cdktf.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentTemplateKnowledgeBases[] | undefined;
    private _model;
    get model(): DataDigitaloceanGenaiAgentTemplateModelList;
    putModel(value: DataDigitaloceanGenaiAgentTemplateModel[] | cdktf.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentTemplateModel[] | undefined;
}
export declare class DataDigitaloceanGenaiAgentTemplateList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDigitaloceanGenaiAgentTemplate[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiAgentTemplateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent digitalocean_genai_agent}
*/
export declare class DataDigitaloceanGenaiAgent extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_agent";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiAgent resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiAgent to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_agent digitalocean_genai_agent} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiAgentConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGenaiAgentConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _childAgents;
    get childAgents(): DataDigitaloceanGenaiAgentChildAgentsList;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifCase?;
    get ifCase(): string;
    set ifCase(value: string);
    resetIfCase(): void;
    get ifCaseInput(): string | undefined;
    get instruction(): string;
    private _k?;
    get k(): number;
    set k(value: number);
    resetK(): void;
    get kInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    get modelUuid(): string;
    get name(): string;
    private _parentAgents;
    get parentAgents(): DataDigitaloceanGenaiAgentParentAgentsList;
    get projectId(): string;
    get region(): string;
    private _retrievalMethod?;
    get retrievalMethod(): string;
    set retrievalMethod(value: string);
    resetRetrievalMethod(): void;
    get retrievalMethodInput(): string | undefined;
    get routeCreatedAt(): string;
    private _routeCreatedBy?;
    get routeCreatedBy(): string;
    set routeCreatedBy(value: string);
    resetRouteCreatedBy(): void;
    get routeCreatedByInput(): string | undefined;
    private _routeName?;
    get routeName(): string;
    set routeName(value: string);
    resetRouteName(): void;
    get routeNameInput(): string | undefined;
    private _routeUuid?;
    get routeUuid(): string;
    set routeUuid(value: string);
    resetRouteUuid(): void;
    get routeUuidInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
    get updatedAt(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _agentGuardrail;
    get agentGuardrail(): DataDigitaloceanGenaiAgentAgentGuardrailList;
    putAgentGuardrail(value: DataDigitaloceanGenaiAgentAgentGuardrail[] | cdktf.IResolvable): void;
    resetAgentGuardrail(): void;
    get agentGuardrailInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentAgentGuardrail[] | undefined;
    private _anthropicApiKey;
    get anthropicApiKey(): DataDigitaloceanGenaiAgentAnthropicApiKeyList;
    putAnthropicApiKey(value: DataDigitaloceanGenaiAgentAnthropicApiKey[] | cdktf.IResolvable): void;
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentAnthropicApiKey[] | undefined;
    private _apiKeyInfos;
    get apiKeyInfos(): DataDigitaloceanGenaiAgentApiKeyInfosList;
    putApiKeyInfos(value: DataDigitaloceanGenaiAgentApiKeyInfos[] | cdktf.IResolvable): void;
    resetApiKeyInfos(): void;
    get apiKeyInfosInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentApiKeyInfos[] | undefined;
    private _apiKeys;
    get apiKeys(): DataDigitaloceanGenaiAgentApiKeysList;
    putApiKeys(value: DataDigitaloceanGenaiAgentApiKeys[] | cdktf.IResolvable): void;
    resetApiKeys(): void;
    get apiKeysInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentApiKeys[] | undefined;
    private _chatbot;
    get chatbot(): DataDigitaloceanGenaiAgentChatbotList;
    putChatbot(value: DataDigitaloceanGenaiAgentChatbot[] | cdktf.IResolvable): void;
    resetChatbot(): void;
    get chatbotInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentChatbot[] | undefined;
    private _chatbotIdentifiers;
    get chatbotIdentifiers(): DataDigitaloceanGenaiAgentChatbotIdentifiersList;
    putChatbotIdentifiers(value: DataDigitaloceanGenaiAgentChatbotIdentifiers[] | cdktf.IResolvable): void;
    resetChatbotIdentifiers(): void;
    get chatbotIdentifiersInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentChatbotIdentifiers[] | undefined;
    private _deployment;
    get deployment(): DataDigitaloceanGenaiAgentDeploymentList;
    putDeployment(value: DataDigitaloceanGenaiAgentDeployment[] | cdktf.IResolvable): void;
    resetDeployment(): void;
    get deploymentInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentDeployment[] | undefined;
    private _functions;
    get functions(): DataDigitaloceanGenaiAgentFunctionsList;
    putFunctions(value: DataDigitaloceanGenaiAgentFunctions[] | cdktf.IResolvable): void;
    resetFunctions(): void;
    get functionsInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentFunctions[] | undefined;
    private _knowledgeBases;
    get knowledgeBases(): DataDigitaloceanGenaiAgentKnowledgeBasesList;
    putKnowledgeBases(value: DataDigitaloceanGenaiAgentKnowledgeBases[] | cdktf.IResolvable): void;
    resetKnowledgeBases(): void;
    get knowledgeBasesInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentKnowledgeBases[] | undefined;
    private _model;
    get model(): DataDigitaloceanGenaiAgentModelList;
    putModel(value: DataDigitaloceanGenaiAgentModel[] | cdktf.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentModel[] | undefined;
    private _openAiApiKey;
    get openAiApiKey(): DataDigitaloceanGenaiAgentOpenAiApiKeyList;
    putOpenAiApiKey(value: DataDigitaloceanGenaiAgentOpenAiApiKey[] | cdktf.IResolvable): void;
    resetOpenAiApiKey(): void;
    get openAiApiKeyInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentOpenAiApiKey[] | undefined;
    private _template;
    get template(): DataDigitaloceanGenaiAgentTemplateList;
    putTemplate(value: DataDigitaloceanGenaiAgentTemplate[] | cdktf.IResolvable): void;
    resetTemplate(): void;
    get templateInput(): cdktf.IResolvable | DataDigitaloceanGenaiAgentTemplate[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
