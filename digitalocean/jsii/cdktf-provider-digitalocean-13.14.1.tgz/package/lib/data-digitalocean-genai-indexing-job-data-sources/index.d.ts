/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataDigitaloceanGenaiIndexingJobDataSourcesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_indexing_job_data_sources#id DataDigitaloceanGenaiIndexingJobDataSources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * UUID of the indexing job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_indexing_job_data_sources#indexing_job_uuid DataDigitaloceanGenaiIndexingJobDataSources#indexing_job_uuid}
    */
    readonly indexingJobUuid: string;
}
export interface DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSources {
}
export declare function dataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSourcesToTerraform(struct?: DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSources): any;
export declare function dataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSourcesToHclTerraform(struct?: DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSources): any;
export declare class DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSources | undefined;
    set internalValue(value: DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSources | undefined);
    get completedAt(): string;
    get dataSourceUuid(): string;
    get errorDetails(): string;
    get errorMsg(): string;
    get failedItemCount(): string;
    get indexedFileCount(): string;
    get indexedItemCount(): string;
    get removedItemCount(): string;
    get skippedItemCount(): string;
    get startedAt(): string;
    get status(): string;
    get totalBytes(): string;
    get totalBytesIndexed(): string;
    get totalFileCount(): string;
}
export declare class DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_indexing_job_data_sources digitalocean_genai_indexing_job_data_sources}
*/
export declare class DataDigitaloceanGenaiIndexingJobDataSources extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "digitalocean_genai_indexing_job_data_sources";
    /**
    * Generates CDKTF code for importing a DataDigitaloceanGenaiIndexingJobDataSources resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDigitaloceanGenaiIndexingJobDataSources to import
    * @param importFromId The id of the existing DataDigitaloceanGenaiIndexingJobDataSources that should be imported. Refer to the {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_indexing_job_data_sources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDigitaloceanGenaiIndexingJobDataSources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/digitalocean/digitalocean/2.71.0/docs/data-sources/genai_indexing_job_data_sources digitalocean_genai_indexing_job_data_sources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDigitaloceanGenaiIndexingJobDataSourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataDigitaloceanGenaiIndexingJobDataSourcesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexedDataSources;
    get indexedDataSources(): DataDigitaloceanGenaiIndexingJobDataSourcesIndexedDataSourcesList;
    private _indexingJobUuid?;
    get indexingJobUuid(): string;
    set indexingJobUuid(value: string);
    get indexingJobUuidInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
